#!/bin/bash
set -euo pipefail

# Run on macOS with Xcode installed. The resulting IPA is intentionally
# unsigned and can be signed later with the user's own development identity.

project_root="$(cd "$(dirname "$0")/.." && pwd)"
build_root="${TMPDIR:-/tmp}/PocketWinUnsignedBuild"
output_root="$project_root/Build"

mkdir -p "$build_root" "$output_root"

xcodebuild \
  -project "$project_root/PocketWin.xcodeproj" \
  -scheme PocketWin \
  -configuration Release \
  -sdk iphoneos \
  -derivedDataPath "$build_root/DerivedData" \
  CODE_SIGNING_ALLOWED=NO \
  CODE_SIGNING_REQUIRED=NO \
  CODE_SIGN_IDENTITY= \
  build

app_path="$build_root/DerivedData/Build/Products/Release-iphoneos/PocketWin.app"
if [[ ! -d "$app_path" ]]; then
  echo "error: Xcode did not produce PocketWin.app"
  exit 1
fi

payload="$build_root/Payload"
rm -rf "$payload"
mkdir -p "$payload"
cp -R "$app_path" "$payload/"

ipa_path="$output_root/PocketWin-unsigned.ipa"
rm -f "$ipa_path"
(cd "$build_root" && /usr/bin/zip -qry "$ipa_path" Payload)
echo "$ipa_path"

