#!/usr/bin/env python3
"""Static, dependency-free integrity checks for the PocketWin source bundle."""

from __future__ import annotations

import json
import plistlib
import re
import sys
import xml.etree.ElementTree as ET
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def check(condition: bool, message: str) -> None:
    if not condition:
        raise RuntimeError(message)
    print(f"ok: {message}")


def stripped_openstep(text: str) -> str:
    text = re.sub(r"/\*.*?\*/", "", text, flags=re.S)
    text = re.sub(r"//[^\n]*", "", text)
    text = re.sub(r'"(?:\\.|[^"\\])*"', '""', text)
    return text


def validate_pbxproj() -> None:
    path = ROOT / "PocketWin.xcodeproj/project.pbxproj"
    text = path.read_text(encoding="utf-8")
    clean = stripped_openstep(text)
    stack: list[str] = []
    matching = {"}": "{", ")": "("}
    for character in clean:
        if character in "{(":
            stack.append(character)
        elif character in matching:
            if not stack or stack.pop() != matching[character]:
                raise RuntimeError("Xcode project contains a mismatched delimiter")
    check(not stack, "Xcode project has no unclosed delimiter")

    definitions = set(re.findall(r"^\s*([A-F0-9]{24}) /\*.*?\*/ = \{", text, flags=re.M))
    references = set(re.findall(r"\b([A-F0-9]{24}) /\*", text))
    missing = sorted(references - definitions)
    check(not missing, f"all {len(references)} PBX object references resolve")

    compiled = set(re.findall(r"/\* ([^/]+\.(?:c|m)) in Sources \*/", text))
    expected = {path.name for path in (ROOT / "Sources").rglob("*")
                if path.suffix in {".c", ".m"}}
    check(compiled == expected,
          f"all {len(expected)} application source files are in the build phase")
    check("PocketWin.app" in text and "name = PocketWin;" in text,
          "PocketWin target and product are declared")


def validate_resources() -> None:
    for relative in (
        "Sources/App/Info.plist",
        "Sources/App/PocketWin.entitlements",
        "Sources/App/PocketWin.OptionalMemory.entitlements",
    ):
        with (ROOT / relative).open("rb") as handle:
            plistlib.load(handle)
        print(f"ok: valid plist {relative}")

    ET.parse(ROOT / "PocketWin.xcodeproj/xcshareddata/xcschemes/PocketWin.xcscheme")
    print("ok: shared Xcode scheme is valid XML")

    for path in (ROOT / "Resources/Assets.xcassets").rglob("Contents.json"):
        json.loads(path.read_text(encoding="utf-8"))
    print("ok: asset catalog JSON is valid")

    icon = ROOT / "Resources/Assets.xcassets/AppIcon.appiconset/AppIcon.png"
    check(icon.read_bytes().startswith(b"\x89PNG\r\n\x1a\n"), "app icon is a PNG")
    for name in ("WGTest.exe", "WGProbe.exe"):
        data = (ROOT / "Resources/TestPrograms" / name).read_bytes()
        check(data[:2] == b"MZ" and data[0x3C:0x40] != b"\0\0\0\0",
              f"{name} is a real PE fixture")


def validate_runtime() -> None:
    blink_sources = list((ROOT / "Vendor/blink/upstream/blink").glob("*.c"))
    check(len(blink_sources) >= 100, f"vendored Blink tree contains {len(blink_sources)} C sources")
    required = (
        "Sources/Core/wg_engine.c",
        "Sources/Core/wg_blink_bridge.c",
        "Vendor/blink/wg_blink_impl.c",
        "Sources/PE/wg_pe_loader.c",
        "Sources/Win32/wg_dll_mapper.c",
        "Sources/Graphics/WGCompositor.m",
        "Sources/App/WGRootViewController.m",
        "Sources/App/WGRuntimeViewController.m",
    )
    check(all((ROOT / path).is_file() for path in required),
          "loader, CPU bridge, Win32 HLE, renderer and launcher sources exist")


def main() -> int:
    try:
        validate_pbxproj()
        validate_resources()
        validate_runtime()
    except (OSError, ValueError, RuntimeError, ET.ParseError) as error:
        print(f"validation failed: {error}", file=sys.stderr)
        return 1
    print("PocketWin project integrity checks passed")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
