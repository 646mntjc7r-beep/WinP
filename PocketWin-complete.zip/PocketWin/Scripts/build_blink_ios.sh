#!/bin/bash
set -euo pipefail

# Builds the vendored Blink CPU core for the active iPhoneOS architecture.
# This script is an Xcode build phase; every input needed for an offline build
# lives in Vendor/blink.  Products are written only to Derived Data.

if [[ "${PLATFORM_NAME:-iphoneos}" != "iphoneos" ]]; then
  echo "error: PocketWin's runtime target is device-only (iphoneos/arm64)."
  exit 1
fi

project_root="${SRCROOT:?SRCROOT is required}"
blink_root="$project_root/Vendor/blink/upstream"
adapter_source="$project_root/Vendor/blink/wg_blink_impl.c"
output_root="${DERIVED_FILE_DIR:?DERIVED_FILE_DIR is required}/PocketWinBlink"
object_root="$output_root/objects"
config_root="$output_root/config"
archive_path="$output_root/blink.a"
adapter_path="$output_root/wg_blink_impl.o"

mkdir -p "$object_root" "$config_root"

enable_jit="${POCKETWIN_ENABLE_JIT:-NO}"
next_config="$config_root/config.h.next"
if [[ "$enable_jit" == "YES" ]]; then
  cp "$project_root/Vendor/blink/include/config.h" "$next_config"
  jit_define="-DPOCKETWIN_BLINK_JIT=1"
  echo "PocketWin: building Blink with JIT support enabled"
else
  {
    echo '#define DISABLE_JIT 1'
    cat "$project_root/Vendor/blink/include/config.h"
  } > "$next_config"
  jit_define="-DPOCKETWIN_BLINK_JIT=0"
  echo "PocketWin: building Blink interpreter (stock-iOS safe)"
fi

if [[ ! -f "$config_root/config.h" ]] || ! cmp -s "$next_config" "$config_root/config.h"; then
  mv "$next_config" "$config_root/config.h"
else
  rm -f "$next_config"
fi

compiler="$(xcrun --sdk iphoneos --find clang)"
archiver="$(xcrun --sdk iphoneos --find ar)"
target_arch="${CURRENT_ARCH:-arm64}"

common_flags=(
  -arch "$target_arch"
  -isysroot "${SDKROOT:?SDKROOT is required}"
  -miphoneos-version-min="${IPHONEOS_DEPLOYMENT_TARGET:-17.0}"
  -std=gnu11
  -fno-common
  -fPIC
  -O2
  -gline-tables-only
  -fno-omit-frame-pointer
  -U_FORTIFY_SOURCE
  -D_FILE_OFFSET_BITS=64
  -D_DARWIN_C_SOURCE
  -D_DEFAULT_SOURCE
  -D_BSD_SOURCE
  -D_GNU_SOURCE
  "$jit_define"
  -iquote "$config_root"
  -iquote "$blink_root"
  -Wno-deprecated-declarations
  -Wno-unused-function
  -Wno-unused-variable
  -Wno-sign-compare
)

objects=()
while IFS= read -r source; do
  base="$(basename "$source" .c)"
  object="$object_root/$base.o"
  objects+=("$object")
  if [[ ! -f "$object" || "$source" -nt "$object" || "$config_root/config.h" -nt "$object" ]]; then
    if [[ "$base" == "uop" ]]; then
      "$compiler" "${common_flags[@]}" \
        -fomit-frame-pointer -fno-stack-protector -fno-sanitize=all \
        -c "$source" -o "$object"
    elif [[ "$base" == "sse2" ]]; then
      "$compiler" "${common_flags[@]}" -O3 -c "$source" -o "$object"
    else
      "$compiler" "${common_flags[@]}" -c "$source" -o "$object"
    fi
  fi
done < <(find "$blink_root/blink" -maxdepth 1 -type f -name '*.c' \
          ! -name 'blink.c' ! -name 'blinkenlights.c' | LC_ALL=C sort)

if [[ ${#objects[@]} -eq 0 ]]; then
  echo "error: no Blink sources were found"
  exit 1
fi

"$archiver" rcs "$archive_path" "${objects[@]}"

if [[ ! -f "$adapter_path" || "$adapter_source" -nt "$adapter_path" || "$config_root/config.h" -nt "$adapter_path" ]]; then
  "$compiler" "${common_flags[@]}" -c "$adapter_source" -o "$adapter_path"
fi

echo "PocketWin: runtime ready at $output_root"
