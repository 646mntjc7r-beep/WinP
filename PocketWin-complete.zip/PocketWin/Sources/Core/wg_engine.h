#ifndef WG_ENGINE_H
#define WG_ENGINE_H

#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>

typedef struct WGEngine WGEngine;

WGEngine *wg_engine_create(void);
void      wg_engine_destroy(WGEngine *engine);

bool wg_engine_init(WGEngine *engine);
void wg_engine_set_jit_enabled(WGEngine *engine, bool enabled);
bool wg_engine_load_pe(WGEngine *engine, const char *path);
bool wg_engine_load_pe_memory(WGEngine *engine, const uint8_t *data, size_t size);
bool wg_engine_run(WGEngine *engine);
void wg_engine_tick(WGEngine *engine);
void wg_engine_stop(WGEngine *engine);

typedef enum {
    WG_ENGINE_IDLE,
    WG_ENGINE_LOADED,
    WG_ENGINE_RUNNING,
    WG_ENGINE_PAUSED,    // paused on DialogBoxParamW — waiting for user
    WG_ENGINE_STOPPED,
    WG_ENGINE_ERROR
} WGEngineState;

// Resume from PAUSED state (e.g., after dialog dismissed)
void wg_engine_resume(WGEngine *engine);

// Modal-dialog input. wg_engine_dialog_active() is true while a wizard dialog
// is up and waiting; wg_engine_dialog_command() delivers a button click
// (1=Next/Install, 2=Cancel, 3=Back) so the wizard advances.
bool wg_engine_dialog_active(WGEngine *engine);
void wg_engine_dialog_command(WGEngine *engine, uint32_t ctrl_id);

// Hit-test a point in the compositor's 800x600 virtual space; returns the modal
// dialog button id under it (Back/Next/Cancel) or 0. Tap rendered wizard buttons.
uint32_t wg_engine_hit_test(WGEngine *engine, int virt_x, int virt_y);

// Host input for ordinary 32-bit Win32 windows. Coordinates use the same
// 800x600 virtual desktop as the compositor. The functions enqueue events and
// are safe to call from UIKit's main thread while the emulator runs elsewhere.
bool wg_engine_post_mouse(WGEngine *engine, uint32_t message,
                          int virt_x, int virt_y, int wheel_delta);
bool wg_engine_post_key(WGEngine *engine, uint32_t virtual_key, bool pressed);
bool wg_engine_post_text(WGEngine *engine, uint16_t utf16_character);

WGEngineState wg_engine_get_state(const WGEngine *engine);
WGEngineState wg_engine_run_sync(WGEngine *engine, int max_ticks);

// Returns true after the guest has supplied an ExitProcess/CRT return code.
bool wg_engine_get_exit_code(const WGEngine *engine, uint32_t *out_code);

// If the just-exited program asked to launch another (the Steam bootstrapper),
// returns its real path and clears it (one-shot); else returns NULL. The app
// chain-loads it after the engine stops.
const char *wg_engine_take_pending_exec(WGEngine *engine);

#endif
