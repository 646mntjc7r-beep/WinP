#import "WGRootViewController.h"
#import "WGStore.h"
#import "WGRuntimeViewController.h"
#include "wg_blink_bridge.h"
#import <Metal/Metal.h>
#import <UniformTypeIdentifiers/UniformTypeIdentifiers.h>

static void WGPresentError(UIViewController *controller, NSString *title, NSError *error) {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:title
        message:error.localizedDescription ?: @"Unbekannter Fehler" preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleCancel handler:nil]];
    [controller presentViewController:alert animated:YES completion:nil];
}

static NSString *WGFormatBytes(NSNumber *bytes) {
    NSByteCountFormatter *formatter = [NSByteCountFormatter new];
    formatter.countStyle = NSByteCountFormatterCountStyleFile;
    return [formatter stringFromByteCount:bytes.longLongValue];
}

@interface WGAppsViewController : UITableViewController <UIDocumentPickerDelegate>
@end
@interface WGBottlesViewController : UITableViewController <UIDocumentPickerDelegate>
@end
@interface WGFilesViewController : UITableViewController <UIDocumentPickerDelegate>
@property (nonatomic) NSDictionary *folderBottle;
@end
@interface WGSettingsViewController : UITableViewController
@end
@interface WGBottleDetailViewController : UITableViewController <UIDocumentPickerDelegate>
- (instancetype)initWithBottle:(NSDictionary *)bottle;
@end
@interface WGLogViewController : UIViewController
@end
@interface WGComponentsViewController : UITableViewController
@end
@interface WGFileBrowserViewController : UITableViewController
- (instancetype)initWithURL:(NSURL *)url title:(NSString *)title;
@end
@interface WGTextEditorViewController : UIViewController
- (instancetype)initWithURL:(NSURL *)url title:(NSString *)title;
@end
@interface WGJSONEditorViewController : UIViewController
- (instancetype)initWithTitle:(NSString *)title value:(NSDictionary *)value
                          save:(void (^)(NSDictionary *value))save;
@end

#pragma mark - Bottle detail

@interface WGBottleDetailViewController ()
@property (nonatomic) NSDictionary *bottle;
@end

@implementation WGBottleDetailViewController

- (instancetype)initWithBottle:(NSDictionary *)bottle {
    self = [super initWithStyle:UITableViewStyleInsetGrouped];
    if (self) { _bottle = bottle; self.title = bottle[@"name"]; }
    return self;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView { return 3; }
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return section == 0 ? 7 : (section == 1 ? 5 : 3);
}
- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    return @[@"Umgebung", @"Verwaltung", @"Lebenszyklus"][section];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:nil];
    if (indexPath.section == 0) {
        NSArray *titles = @[@"Windows-Version", @"RAM-Limit", @"CPU-Kerne", @"Auflösung", @"DPI", @"Renderer", @"JIT"];
        NSArray *values = @[self.bottle[@"windowsVersion"], [NSString stringWithFormat:@"%@ MB",self.bottle[@"ramMB"]],
                            [self.bottle[@"cpuCores"] stringValue], self.bottle[@"resolution"],
                            [self.bottle[@"dpi"] stringValue], self.bottle[@"renderer"],
                            wg_blink_has_jit() ? ([self.bottle[@"jit"] boolValue] ? @"Ein" : @"Aus") : @"Nicht kompiliert"];
        cell.textLabel.text = titles[indexPath.row];
        cell.detailTextLabel.text = values[indexPath.row];
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    } else if (indexPath.section == 1) {
        cell.textLabel.text = @[@"Environment Variables", @"DLL Overrides", @"Registry öffnen", @"Laufwerke verwalten", @"Dateien durchsuchen"][indexPath.row];
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    } else {
        cell.textLabel.text = @[@"Bottle exportieren", @"Bottle duplizieren", @"Bottle löschen"][indexPath.row];
        if (indexPath.row == 2) cell.textLabel.textColor = UIColor.systemRedColor;
    }
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    if (indexPath.section == 0) [self editEnvironmentRow:indexPath.row];
    else if (indexPath.section == 1) [self manageRow:indexPath.row];
    else [self lifecycleRow:indexPath.row];
}

- (void)choose:(NSString *)title key:(NSString *)key values:(NSArray *)values {
    UIAlertController *sheet = [UIAlertController alertControllerWithTitle:title message:nil preferredStyle:UIAlertControllerStyleActionSheet];
    for (id value in values) {
        [sheet addAction:[UIAlertAction actionWithTitle:[value description] style:UIAlertActionStyleDefault handler:^(UIAlertAction *a) {
            [WGStore.shared updateBottle:self.bottle values:@{key:value} error:nil];
            self.bottle = [WGStore.shared bottleWithID:self.bottle[@"id"]];
            [self.tableView reloadData];
        }]];
    }
    [sheet addAction:[UIAlertAction actionWithTitle:@"Abbrechen" style:UIAlertActionStyleCancel handler:nil]];
    sheet.popoverPresentationController.sourceView = self.view;
    sheet.popoverPresentationController.sourceRect = CGRectMake(CGRectGetMidX(self.view.bounds), 80, 1, 1);
    [self presentViewController:sheet animated:YES completion:nil];
}

- (void)editEnvironmentRow:(NSInteger)row {
    switch (row) {
        case 0: [self choose:@"Windows-Version" key:@"windowsVersion" values:@[@"Windows 7", @"Windows 10", @"Windows 11"]]; break;
        case 1: [self choose:@"RAM-Limit" key:@"ramMB" values:@[@256, @512, @1024, @1536, @2048]]; break;
        case 2: [self choose:@"CPU-Kerne" key:@"cpuCores" values:@[@1, @2, @4, @6]]; break;
        case 3: [self choose:@"Auflösung" key:@"resolution" values:@[@"Auto", @"800×600", @"1024×768", @"1280×720", @"1280×800", @"1920×1080"]]; break;
        case 4: [self choose:@"DPI" key:@"dpi" values:@[@96, @120, @144, @192]]; break;
        case 5: [self choose:@"Renderer" key:@"renderer" values:@[@"Metal/GDI"]]; break;
        case 6: {
            NSString *message = wg_blink_has_jit()
                ? @"JIT wurde in diesen Build kompiliert. Die Bottle kann es ein- oder ausschalten."
                : @"Dieser stock-iOS-sichere Build enthält nur den Interpreter. Für einen JIT-Build muss POCKETWIN_ENABLE_JIT=YES beim Kompilieren gesetzt und JIT extern freigeschaltet werden.";
            UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"JIT" message:message preferredStyle:UIAlertControllerStyleAlert];
            if (wg_blink_has_jit()) {
                [alert addAction:[UIAlertAction actionWithTitle:@"Umschalten" style:UIAlertActionStyleDefault handler:^(UIAlertAction *a) {
                    [WGStore.shared updateBottle:self.bottle values:@{@"jit":@(![self.bottle[@"jit"] boolValue])} error:nil];
                    self.bottle = [WGStore.shared bottleWithID:self.bottle[@"id"]];
                    [self.tableView reloadData];
                }]];
            }
            [alert addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleCancel handler:nil]];
            [self presentViewController:alert animated:YES completion:nil];
            break;
        }
    }
}

- (void)manageRow:(NSInteger)row {
    if (row == 0 || row == 1) {
        NSString *key = row == 0 ? @"environment" : @"dllOverrides";
        WGJSONEditorViewController *editor = [[WGJSONEditorViewController alloc]
            initWithTitle:(row == 0 ? @"Environment Variables" : @"DLL Overrides")
            value:self.bottle[key] ?: @{}
            save:^(NSDictionary *value) {
                [WGStore.shared updateBottle:self.bottle values:@{key:value} error:nil];
            }];
        [self.navigationController pushViewController:editor animated:YES];
    } else if (row == 2) {
        NSURL *root = [WGStore.shared URLForBottle:self.bottle];
        UIAlertController *sheet = [UIAlertController alertControllerWithTitle:@"Registry" message:nil preferredStyle:UIAlertControllerStyleActionSheet];
        for (NSString *name in @[@"system.reg", @"user.reg", @"userdef.reg"]) {
            [sheet addAction:[UIAlertAction actionWithTitle:name style:UIAlertActionStyleDefault handler:^(UIAlertAction *a) {
                [self.navigationController pushViewController:[[WGTextEditorViewController alloc]
                    initWithURL:[root URLByAppendingPathComponent:name] title:name] animated:YES];
            }]];
        }
        [sheet addAction:[UIAlertAction actionWithTitle:@"Abbrechen" style:UIAlertActionStyleCancel handler:nil]];
        sheet.popoverPresentationController.sourceView = self.view;
        [self presentViewController:sheet animated:YES completion:nil];
    } else if (row == 3) {
        UIDocumentPickerViewController *picker = [[UIDocumentPickerViewController alloc] initForOpeningContentTypes:@[UTTypeFolder]];
        picker.delegate = self;
        [self presentViewController:picker animated:YES completion:nil];
    } else {
        NSURL *drive = [[WGStore.shared URLForBottle:self.bottle] URLByAppendingPathComponent:@"drive_c" isDirectory:YES];
        [self.navigationController pushViewController:[[WGFileBrowserViewController alloc] initWithURL:drive title:@"C:\\"] animated:YES];
    }
}

- (void)documentPicker:(UIDocumentPickerViewController *)controller didPickDocumentsAtURLs:(NSArray<NSURL *> *)urls {
    NSError *error = nil;
    if (![WGStore.shared setSharedFolderURL:urls.firstObject forBottle:self.bottle error:&error])
        WGPresentError(self, @"Laufwerk D: konnte nicht verbunden werden", error);
}

- (void)lifecycleRow:(NSInteger)row {
    if (row == 0) {
        NSURL *url = [WGStore.shared URLForBottle:self.bottle];
        UIActivityViewController *share = [[UIActivityViewController alloc] initWithActivityItems:@[url] applicationActivities:nil];
        share.popoverPresentationController.sourceView = self.view;
        [self presentViewController:share animated:YES completion:nil];
    } else if (row == 1) {
        NSError *error = nil;
        if (![WGStore.shared duplicateBottle:self.bottle error:&error]) WGPresentError(self, @"Duplizieren fehlgeschlagen", error);
    } else {
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Bottle löschen?"
            message:@"Alle darin importierten Programme und Dateien werden gelöscht." preferredStyle:UIAlertControllerStyleAlert];
        [alert addAction:[UIAlertAction actionWithTitle:@"Löschen" style:UIAlertActionStyleDestructive handler:^(UIAlertAction *a) {
            NSError *error = nil;
            if ([WGStore.shared deleteBottle:self.bottle error:&error]) [self.navigationController popViewControllerAnimated:YES];
            else WGPresentError(self, @"Löschen fehlgeschlagen", error);
        }]];
        [alert addAction:[UIAlertAction actionWithTitle:@"Abbrechen" style:UIAlertActionStyleCancel handler:nil]];
        [self presentViewController:alert animated:YES completion:nil];
    }
}

@end

#pragma mark - Files

@implementation WGFilesViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [NSNotificationCenter.defaultCenter addObserver:self selector:@selector(reload)
                                               name:WGStoreDidChangeNotification object:nil];
}
- (void)reload { [self.tableView reloadData]; }
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section { return WGStore.shared.bottles.count; }
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:nil];
    NSDictionary *bottle = WGStore.shared.bottles[indexPath.row];
    cell.textLabel.text = bottle[@"name"];
    cell.detailTextLabel.text = [NSString stringWithFormat:@"C: Bottle · D: %@", bottle[@"sharedFolderName"] ?: @"Nicht verbunden"];
    cell.imageView.image = [UIImage systemImageNamed:@"externaldrive.fill"];
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    return cell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    NSDictionary *bottle = WGStore.shared.bottles[indexPath.row];
    UIAlertController *sheet = [UIAlertController alertControllerWithTitle:bottle[@"name"] message:nil preferredStyle:UIAlertControllerStyleActionSheet];
    [sheet addAction:[UIAlertAction actionWithTitle:@"C: durchsuchen" style:UIAlertActionStyleDefault handler:^(UIAlertAction *a) {
        NSURL *drive = [[WGStore.shared URLForBottle:bottle] URLByAppendingPathComponent:@"drive_c" isDirectory:YES];
        [self.navigationController pushViewController:[[WGFileBrowserViewController alloc] initWithURL:drive title:@"C:\\"] animated:YES];
    }]];
    [sheet addAction:[UIAlertAction actionWithTitle:@"Ordner als D: auswählen" style:UIAlertActionStyleDefault handler:^(UIAlertAction *a) {
        self.folderBottle = bottle;
        UIDocumentPickerViewController *picker = [[UIDocumentPickerViewController alloc] initForOpeningContentTypes:@[UTTypeFolder]];
        picker.delegate = self;
        [self presentViewController:picker animated:YES completion:nil];
    }]];
    [sheet addAction:[UIAlertAction actionWithTitle:@"Abbrechen" style:UIAlertActionStyleCancel handler:nil]];
    sheet.popoverPresentationController.sourceView = self.view;
    [self presentViewController:sheet animated:YES completion:nil];
}
- (void)documentPicker:(UIDocumentPickerViewController *)controller didPickDocumentsAtURLs:(NSArray<NSURL *> *)urls {
    NSError *error = nil;
    if (![WGStore.shared setSharedFolderURL:urls.firstObject forBottle:self.folderBottle error:&error])
        WGPresentError(self, @"Ordnerfreigabe fehlgeschlagen", error);
    self.folderBottle = nil;
}
@end
@implementation WGRootViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.tabBar.tintColor = [UIColor colorWithRed:0.16 green:0.43 blue:0.94 alpha:1];
    self.viewControllers = @[
        [self navigationWith:[WGAppsViewController new] title:@"Apps" symbol:@"square.grid.2x2.fill"],
        [self navigationWith:[WGBottlesViewController new] title:@"Bottles" symbol:@"shippingbox.fill"],
        [self navigationWith:[WGFilesViewController new] title:@"Dateien" symbol:@"folder.fill"],
        [self navigationWith:[WGSettingsViewController new] title:@"Einstellungen" symbol:@"gearshape.fill"]
    ];
}

- (UINavigationController *)navigationWith:(UIViewController *)controller title:(NSString *)title symbol:(NSString *)symbol {
    controller.title = title;
    UINavigationController *navigation = [[UINavigationController alloc] initWithRootViewController:controller];
    navigation.tabBarItem = [[UITabBarItem alloc] initWithTitle:title image:[UIImage systemImageNamed:symbol] tag:0];
    navigation.navigationBar.prefersLargeTitles = YES;
    return navigation;
}

- (UIInterfaceOrientationMask)supportedInterfaceOrientations {
    return self.presentedViewController ? self.presentedViewController.supportedInterfaceOrientations
                                        : UIInterfaceOrientationMaskAllButUpsideDown;
}

@end

#pragma mark - Apps

@implementation WGAppsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
    self.tableView.rowHeight = 86;
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc]
        initWithBarButtonSystemItem:UIBarButtonSystemItemAdd target:self action:@selector(addExecutable)];
    [NSNotificationCenter.defaultCenter addObserver:self selector:@selector(reload)
                                               name:WGStoreDidChangeNotification object:nil];
    [self buildHeader];
    [self reload];
}

- (void)buildHeader {
    UIView *header = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 1, 86)];
    UIButton *button = [UIButton buttonWithType:UIButtonTypeSystem];
    button.translatesAutoresizingMaskIntoConstraints = NO;
    [button setTitle:@"＋ EXE hinzufügen" forState:UIControlStateNormal];
    button.titleLabel.font = [UIFont systemFontOfSize:18 weight:UIFontWeightSemibold];
    button.backgroundColor = [UIColor colorWithRed:0.16 green:0.43 blue:0.94 alpha:1];
    [button setTitleColor:UIColor.whiteColor forState:UIControlStateNormal];
    button.layer.cornerRadius = 14;
    [button addTarget:self action:@selector(addExecutable) forControlEvents:UIControlEventTouchUpInside];
    [header addSubview:button];
    [NSLayoutConstraint activateConstraints:@[
        [button.leadingAnchor constraintEqualToAnchor:header.leadingAnchor constant:20],
        [button.trailingAnchor constraintEqualToAnchor:header.trailingAnchor constant:-20],
        [button.topAnchor constraintEqualToAnchor:header.topAnchor constant:14],
        [button.bottomAnchor constraintEqualToAnchor:header.bottomAnchor constant:-14]
    ]];
    self.tableView.tableHeaderView = header;
}

- (void)reload {
    [self.tableView reloadData];
    if (WGStore.shared.programs.count == 0) {
        UILabel *empty = [UILabel new];
        empty.text = @"Keine Windows-Programme installiert\n\nImportiere eine EXE, MSI-, BAT- oder CMD-Datei.";
        empty.textAlignment = NSTextAlignmentCenter;
        empty.numberOfLines = 0;
        empty.textColor = UIColor.secondaryLabelColor;
        self.tableView.backgroundView = empty;
    } else self.tableView.backgroundView = nil;
}

- (void)addExecutable {
    NSMutableArray<UTType *> *types = [NSMutableArray array];
    for (NSString *extension in @[@"exe", @"msi", @"bat", @"cmd"]) {
        UTType *type = [UTType typeWithFilenameExtension:extension];
        if (type) [types addObject:type];
    }
    [types addObject:UTTypeData];
    UIDocumentPickerViewController *picker = [[UIDocumentPickerViewController alloc] initForOpeningContentTypes:types];
    picker.delegate = self;
    picker.allowsMultipleSelection = YES;
    [self presentViewController:picker animated:YES completion:nil];
}

- (void)documentPicker:(UIDocumentPickerViewController *)controller didPickDocumentsAtURLs:(NSArray<NSURL *> *)urls {
    NSMutableArray<NSString *> *failures = [NSMutableArray array];
    for (NSURL *url in urls) {
        NSError *error = nil;
        if (![WGStore.shared importProgramAtURL:url bottleID:nil error:&error])
            [failures addObject:[NSString stringWithFormat:@"%@: %@", url.lastPathComponent, error.localizedDescription]];
    }
    if (failures.count) WGPresentError(self, @"Einige Dateien konnten nicht importiert werden",
        [NSError errorWithDomain:@"PocketWin" code:1 userInfo:@{NSLocalizedDescriptionKey:[failures componentsJoinedByString:@"\n"]}]);
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return WGStore.shared.programs.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *identifier = @"Program";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (!cell) cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:identifier];
    NSDictionary *program = WGStore.shared.programs[indexPath.row];
    NSDictionary *bottle = [WGStore.shared bottleWithID:program[@"bottleID"]];
    cell.textLabel.text = program[@"name"];
    cell.textLabel.font = [UIFont systemFontOfSize:17 weight:UIFontWeightSemibold];
    NSString *last = [program[@"lastLaunch"] length] ? program[@"lastLaunch"] : @"Noch nie gestartet";
    cell.detailTextLabel.text = [NSString stringWithFormat:@"%@ · %@ · %@\n%@ · %@",
        program[@"architecture"], bottle[@"name"] ?: @"Keine Bottle", program[@"compatibility"],
        WGFormatBytes(program[@"size"]), last];
    cell.detailTextLabel.numberOfLines = 2;
    cell.imageView.image = [UIImage systemImageNamed:@"app.badge.fill"];
    cell.imageView.tintColor = [program[@"compatibility"] isEqualToString:@"Hoch"] ? UIColor.systemGreenColor
        : ([program[@"compatibility"] isEqualToString:@"Mittel"] ? UIColor.systemOrangeColor : UIColor.systemRedColor);
    cell.accessoryType = UITableViewCellAccessoryDetailButton;
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    [self startProgram:WGStore.shared.programs[indexPath.row]];
}

- (void)startProgram:(NSDictionary *)program {
    if (![program[@"extension"] isEqualToString:@"exe"]) {
        WGPresentError(self, @"Noch nicht ausführbar", [NSError errorWithDomain:@"PocketWin" code:2
            userInfo:@{NSLocalizedDescriptionKey:program[@"compatibilityReason"] ?: @"Dieses Format ist nicht ausführbar."}]);
        return;
    }
    void (^launch)(void) = ^{
        WGRuntimeViewController *runtime = [[WGRuntimeViewController alloc] initWithProgram:program];
        [self presentViewController:runtime animated:YES completion:nil];
    };
    if ([program[@"compatibility"] isEqualToString:@"Hoch"]) { launch(); return; }
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:
        [NSString stringWithFormat:@"Kompatibilität: %@", program[@"compatibility"]]
        message:program[@"compatibilityReason"] preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:@"Trotzdem starten" style:UIAlertActionStyleDefault handler:^(UIAlertAction *a) { launch(); }]];
    [alert addAction:[UIAlertAction actionWithTitle:@"Abbrechen" style:UIAlertActionStyleCancel handler:nil]];
    [self presentViewController:alert animated:YES completion:nil];
}

- (void)tableView:(UITableView *)tableView accessoryButtonTappedForRowWithIndexPath:(NSIndexPath *)indexPath {
    [self editProgram:WGStore.shared.programs[indexPath.row]];
}

- (void)editProgram:(NSDictionary *)program {
    UIAlertController *sheet = [UIAlertController alertControllerWithTitle:program[@"name"]
        message:@"Programmname oder zugewiesene Bottle ändern." preferredStyle:UIAlertControllerStyleActionSheet];
    [sheet addAction:[UIAlertAction actionWithTitle:@"Umbenennen" style:UIAlertActionStyleDefault handler:^(UIAlertAction *a) {
        UIAlertController *prompt = [UIAlertController alertControllerWithTitle:@"Programmname" message:nil preferredStyle:UIAlertControllerStyleAlert];
        [prompt addTextFieldWithConfigurationHandler:^(UITextField *f) { f.text = program[@"name"]; }];
        [prompt addAction:[UIAlertAction actionWithTitle:@"Speichern" style:UIAlertActionStyleDefault handler:^(UIAlertAction *x) {
            [WGStore.shared updateProgram:program values:@{@"name":prompt.textFields.firstObject.text ?: program[@"name"]} error:nil];
        }]];
        [prompt addAction:[UIAlertAction actionWithTitle:@"Abbrechen" style:UIAlertActionStyleCancel handler:nil]];
        [self presentViewController:prompt animated:YES completion:nil];
    }]];
    for (NSDictionary *bottle in WGStore.shared.bottles) {
        [sheet addAction:[UIAlertAction actionWithTitle:[@"Bottle: " stringByAppendingString:bottle[@"name"]]
            style:UIAlertActionStyleDefault handler:^(UIAlertAction *a) {
                [WGStore.shared updateProgram:program values:@{@"bottleID":bottle[@"id"]} error:nil];
            }]];
    }
    [sheet addAction:[UIAlertAction actionWithTitle:@"Löschen" style:UIAlertActionStyleDestructive handler:^(UIAlertAction *a) {
        [self confirmDeleteProgram:program];
    }]];
    [sheet addAction:[UIAlertAction actionWithTitle:@"Abbrechen" style:UIAlertActionStyleCancel handler:nil]];
    sheet.popoverPresentationController.sourceView = self.view;
    sheet.popoverPresentationController.sourceRect = CGRectMake(CGRectGetMidX(self.view.bounds), CGRectGetMidY(self.view.bounds), 1, 1);
    [self presentViewController:sheet animated:YES completion:nil];
}

- (void)confirmDeleteProgram:(NSDictionary *)program {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Programm löschen?"
        message:@"Die importierte Datei wird aus ihrer Bottle entfernt." preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:@"Löschen" style:UIAlertActionStyleDestructive handler:^(UIAlertAction *a) {
        NSError *error = nil;
        if (![WGStore.shared deleteProgram:program error:&error]) WGPresentError(self, @"Löschen fehlgeschlagen", error);
    }]];
    [alert addAction:[UIAlertAction actionWithTitle:@"Abbrechen" style:UIAlertActionStyleCancel handler:nil]];
    [self presentViewController:alert animated:YES completion:nil];
}

@end

#pragma mark - Bottles

@implementation WGBottlesViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc]
        initWithBarButtonSystemItem:UIBarButtonSystemItemAdd target:self action:@selector(addBottle)];
    [NSNotificationCenter.defaultCenter addObserver:self selector:@selector(reload)
                                               name:WGStoreDidChangeNotification object:nil];
}

- (void)reload { [self.tableView reloadData]; }

- (void)addBottle {
    UIAlertController *sheet = [UIAlertController alertControllerWithTitle:@"Bottle hinzufügen" message:nil preferredStyle:UIAlertControllerStyleActionSheet];
    [sheet addAction:[UIAlertAction actionWithTitle:@"Neu erstellen" style:UIAlertActionStyleDefault handler:^(UIAlertAction *a) {
        UIAlertController *prompt = [UIAlertController alertControllerWithTitle:@"Neue Bottle" message:nil preferredStyle:UIAlertControllerStyleAlert];
        [prompt addTextFieldWithConfigurationHandler:^(UITextField *f) { f.placeholder = @"Name"; }];
        [prompt addAction:[UIAlertAction actionWithTitle:@"Erstellen" style:UIAlertActionStyleDefault handler:^(UIAlertAction *x) {
            [WGStore.shared createBottleNamed:prompt.textFields.firstObject.text];
        }]];
        [prompt addAction:[UIAlertAction actionWithTitle:@"Abbrechen" style:UIAlertActionStyleCancel handler:nil]];
        [self presentViewController:prompt animated:YES completion:nil];
    }]];
    [sheet addAction:[UIAlertAction actionWithTitle:@"Ordner importieren" style:UIAlertActionStyleDefault handler:^(UIAlertAction *a) {
        UIDocumentPickerViewController *picker = [[UIDocumentPickerViewController alloc] initForOpeningContentTypes:@[UTTypeFolder]];
        picker.delegate = self;
        [self presentViewController:picker animated:YES completion:nil];
    }]];
    [sheet addAction:[UIAlertAction actionWithTitle:@"Abbrechen" style:UIAlertActionStyleCancel handler:nil]];
    sheet.popoverPresentationController.barButtonItem = self.navigationItem.rightBarButtonItem;
    [self presentViewController:sheet animated:YES completion:nil];
}

- (void)documentPicker:(UIDocumentPickerViewController *)controller didPickDocumentsAtURLs:(NSArray<NSURL *> *)urls {
    NSError *error = nil;
    if (![WGStore.shared importBottleDirectoryAtURL:urls.firstObject error:&error]) WGPresentError(self, @"Import fehlgeschlagen", error);
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section { return WGStore.shared.bottles.count; }

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"Bottle"];
    if (!cell) cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"Bottle"];
    NSDictionary *bottle = WGStore.shared.bottles[indexPath.row];
    NSUInteger programs = [WGStore.shared.programs filteredArrayUsingPredicate:
        [NSPredicate predicateWithFormat:@"bottleID == %@", bottle[@"id"]]].count;
    cell.textLabel.text = bottle[@"name"];
    cell.detailTextLabel.text = [NSString stringWithFormat:@"%@ · %@ · %@ · %lu Programme",
        bottle[@"windowsVersion"], bottle[@"resolution"], bottle[@"renderer"], (unsigned long)programs];
    cell.imageView.image = [UIImage systemImageNamed:@"shippingbox.fill"];
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    [self.navigationController pushViewController:[[WGBottleDetailViewController alloc]
        initWithBottle:WGStore.shared.bottles[indexPath.row]] animated:YES];
}

- (UISwipeActionsConfiguration *)tableView:(UITableView *)tableView trailingSwipeActionsConfigurationForRowAtIndexPath:(NSIndexPath *)indexPath {
    NSDictionary *bottle = WGStore.shared.bottles[indexPath.row];
    UIContextualAction *duplicate = [UIContextualAction contextualActionWithStyle:UIContextualActionStyleNormal title:@"Duplizieren"
        handler:^(UIContextualAction *a, UIView *v, void (^done)(BOOL)) {
            NSError *error = nil; BOOL ok = [WGStore.shared duplicateBottle:bottle error:&error] != nil;
            if (!ok) WGPresentError(self, @"Duplizieren fehlgeschlagen", error); done(ok);
        }];
    UIContextualAction *remove = [UIContextualAction contextualActionWithStyle:UIContextualActionStyleDestructive title:@"Löschen"
        handler:^(UIContextualAction *a, UIView *v, void (^done)(BOOL)) {
            NSError *error = nil; BOOL ok = [WGStore.shared deleteBottle:bottle error:&error];
            if (!ok) WGPresentError(self, @"Löschen fehlgeschlagen", error); done(ok);
        }];
    return [UISwipeActionsConfiguration configurationWithActions:@[remove, duplicate]];
}

@end

#pragma mark - Settings

@implementation WGSettingsViewController

- (instancetype)init { return [super initWithStyle:UITableViewStyleInsetGrouped]; }
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section { return 6; }

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:nil];
    NSArray *titles = @[@"Runtime", @"Laufzeittest starten", @"Windows-Komponenten", @"Debug-Konsole", @"Lizenzen", @"Systemstatus"];
    NSArray *details = @[
        [NSString stringWithFormat:@"%@ · %@", @"Blink PE-HLE", wg_blink_has_jit() ? @"JIT verfügbar" : @"Interpreter/No-JIT"],
        @"Gebündelte echte PE32-GDI-Testdatei ausführen",
        @"Vorhandene und nicht gebündelte Laufzeitteile",
        @"CPU-, Grafik-, Datei-, DLL- und Netzwerklogs",
        @"Open-Source-Hinweise",
        @"iOS, Architektur und Sandbox"
    ];
    cell.textLabel.text = titles[indexPath.row];
    cell.detailTextLabel.text = details[indexPath.row];
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    if (indexPath.row == 1) {
        NSDictionary *program = nil;
        for (NSDictionary *candidate in WGStore.shared.programs)
            if ([candidate[@"fileName"] isEqualToString:@"WGTest.exe"]) { program = candidate; break; }
        if (!program) {
            NSURL *url = [NSBundle.mainBundle URLForResource:@"WGTest" withExtension:@"exe"];
            NSError *error = nil;
            program = url ? [WGStore.shared importProgramAtURL:url bottleID:nil error:&error] : nil;
            if (!program) { WGPresentError(self, @"Testdatei konnte nicht geladen werden", error); return; }
        }
        [self presentViewController:[[WGRuntimeViewController alloc] initWithProgram:program] animated:YES completion:nil];
    } else if (indexPath.row == 2) {
        [self.navigationController pushViewController:[WGComponentsViewController new] animated:YES];
    } else if (indexPath.row == 3) {
        [self.navigationController pushViewController:[WGLogViewController new] animated:YES];
    } else if (indexPath.row == 4) {
        NSURL *url = [NSBundle.mainBundle URLForResource:@"THIRD_PARTY_NOTICES" withExtension:@"txt"];
        [self.navigationController pushViewController:[[WGTextEditorViewController alloc] initWithURL:url title:@"Lizenzen"] animated:YES];
    } else {
        NSString *message;
        if (indexPath.row == 0) {
            message = @"Lokaler PE32/PE32+-Loader, Blink-x86/x64-Kern und Win32-High-Level-Thunks. Dies ist kein vollständiges Wine und keine Windows-VM.";
        } else {
            message = [NSString stringWithFormat:@"%@ %@\nMetal: %@\nJIT: %@\nPrivate Entitlements: keine",
                UIDevice.currentDevice.systemName, UIDevice.currentDevice.systemVersion,
                MTLCreateSystemDefaultDevice() ? @"verfügbar" : @"nicht verfügbar",
                wg_blink_has_jit() ? @"kompiliert" : @"nicht kompiliert"];
        }
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:(indexPath.row == 0 ? @"Runtime" : @"Systemstatus")
            message:message preferredStyle:UIAlertControllerStyleAlert];
        [alert addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleCancel handler:nil]];
        [self presentViewController:alert animated:YES completion:nil];
    }
}

@end

@implementation WGComponentsViewController

- (void)viewDidLoad { [super viewDidLoad]; self.title = @"Komponenten"; }
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView { return 2; }
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section { return section == 0 ? 6 : 7; }
- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    return section == 0 ? @"Integriert" : @"Nicht gebündelt";
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:nil];
    NSArray *integrated = @[@"PE32/PE32+ Loader", @"x86/x64 CPU-Interpreter", @"Win32 Basis-API",
                            @"GDI/Metal Renderer", @"WinSock/WinHTTP", @"Persistente Registry"];
    NSArray *external = @[@"Visual C++ Redistributable", @".NET Framework", @"DirectX/DXVK",
                          @"Mono", @"Gecko", @"MSI Engine", @"Windows Fonts"];
    BOOL available = indexPath.section == 0;
    cell.textLabel.text = (available ? integrated : external)[indexPath.row];
    cell.detailTextLabel.text = available ? @"Teil der freien HLE-Runtime"
        : @"Nicht enthalten; keine Microsoft-Dateien werden weitergegeben";
    cell.imageView.image = [UIImage systemImageNamed:available ? @"checkmark.circle.fill" : @"minus.circle"];
    cell.imageView.tintColor = available ? UIColor.systemGreenColor : UIColor.systemGrayColor;
    return cell;
}

@end

#pragma mark - Logs and editors

@interface WGLogViewController ()
@property (nonatomic) UITextView *textView;
@end

@implementation WGLogViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"Debug-Konsole";
    self.view.backgroundColor = UIColor.systemBackgroundColor;
    self.textView = [[UITextView alloc] initWithFrame:self.view.bounds];
    self.textView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    self.textView.editable = NO;
    self.textView.font = [UIFont monospacedSystemFontOfSize:11 weight:UIFontWeightRegular];
    [self.view addSubview:self.textView];
    self.navigationItem.rightBarButtonItems = @[
        [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemAction target:self action:@selector(exportLog)],
        [[UIBarButtonItem alloc] initWithTitle:@"Leeren" style:UIBarButtonItemStylePlain target:self action:@selector(clearLog)]
    ];
    [NSNotificationCenter.defaultCenter addObserver:self selector:@selector(refresh) name:WGLogDidChangeNotification object:nil];
    [self refresh];
}

- (void)refresh {
    NSString *log = WGLogCenter.shared.completeLog;
    self.textView.text = log.length ? log : @"Noch keine Logs.";
}
- (void)clearLog { [WGLogCenter.shared clear]; }
- (void)exportLog {
    NSError *error = nil;
    NSURL *url = [WGLogCenter.shared writeExportFile:&error];
    if (!url) { WGPresentError(self, @"Export fehlgeschlagen", error); return; }
    UIActivityViewController *share = [[UIActivityViewController alloc] initWithActivityItems:@[url] applicationActivities:nil];
    share.popoverPresentationController.barButtonItem = self.navigationItem.rightBarButtonItems.firstObject;
    [self presentViewController:share animated:YES completion:nil];
}

@end

@interface WGTextEditorViewController ()
@property (nonatomic) NSURL *url;
@property (nonatomic) UITextView *textView;
@property (nonatomic) BOOL readOnly;
@end

@implementation WGTextEditorViewController

- (instancetype)initWithURL:(NSURL *)url title:(NSString *)title {
    self = [super init];
    if (self) { _url = url; self.title = title; _readOnly = [title isEqualToString:@"Lizenzen"]; }
    return self;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = UIColor.systemBackgroundColor;
    self.textView = [[UITextView alloc] initWithFrame:self.view.bounds];
    self.textView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    self.textView.font = [UIFont monospacedSystemFontOfSize:12 weight:UIFontWeightRegular];
    self.textView.editable = !self.readOnly;
    self.textView.text = self.url ? ([NSString stringWithContentsOfURL:self.url encoding:NSUTF8StringEncoding error:nil] ?: @"") : @"Datei nicht gefunden.";
    [self.view addSubview:self.textView];
    if (!self.readOnly) self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc]
        initWithBarButtonSystemItem:UIBarButtonSystemItemSave target:self action:@selector(saveText)];
}
- (void)saveText {
    NSError *error = nil;
    if (![self.textView.text writeToURL:self.url atomically:YES encoding:NSUTF8StringEncoding error:&error])
        WGPresentError(self, @"Speichern fehlgeschlagen", error);
}

@end

@interface WGJSONEditorViewController ()
@property (nonatomic) UITextView *textView;
@property (nonatomic, copy) void (^saveBlock)(NSDictionary *value);
@end

@implementation WGJSONEditorViewController

- (instancetype)initWithTitle:(NSString *)title value:(NSDictionary *)value save:(void (^)(NSDictionary *))save {
    self = [super init];
    if (self) {
        self.title = title;
        _saveBlock = [save copy];
        NSData *data = [NSJSONSerialization dataWithJSONObject:value options:NSJSONWritingPrettyPrinted error:nil];
        _textView = [UITextView new];
        _textView.text = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
    }
    return self;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = UIColor.systemBackgroundColor;
    self.textView.frame = self.view.bounds;
    self.textView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    self.textView.font = [UIFont monospacedSystemFontOfSize:13 weight:UIFontWeightRegular];
    [self.view addSubview:self.textView];
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc]
        initWithBarButtonSystemItem:UIBarButtonSystemItemSave target:self action:@selector(saveJSON)];
}
- (void)saveJSON {
    NSError *error = nil;
    NSData *data = [self.textView.text dataUsingEncoding:NSUTF8StringEncoding];
    id value = [NSJSONSerialization JSONObjectWithData:data options:0 error:&error];
    if (![value isKindOfClass:NSDictionary.class]) {
        if (!error) error = [NSError errorWithDomain:@"PocketWin" code:1
            userInfo:@{NSLocalizedDescriptionKey:@"Die Wurzel muss ein JSON-Objekt sein."}];
        WGPresentError(self, @"Ungültiges JSON", error);
        return;
    }
    self.saveBlock(value);
    [self.navigationController popViewControllerAnimated:YES];
}

@end

#pragma mark - File browser

@interface WGFileBrowserViewController ()
@property (nonatomic) NSURL *directory;
@property (nonatomic) NSArray<NSURL *> *entries;
@end

@implementation WGFileBrowserViewController

- (instancetype)initWithURL:(NSURL *)url title:(NSString *)title {
    self = [super init];
    if (self) { _directory = url; self.title = title; }
    return self;
}
- (void)viewDidLoad { [super viewDidLoad]; [self reloadEntries]; }
- (void)reloadEntries {
    NSArray *keys = @[NSURLIsDirectoryKey, NSURLFileSizeKey];
    self.entries = [[NSFileManager.defaultManager contentsOfDirectoryAtURL:self.directory
        includingPropertiesForKeys:keys options:NSDirectoryEnumerationSkipsHiddenFiles error:nil]
        sortedArrayUsingComparator:^NSComparisonResult(NSURL *a, NSURL *b) {
            return [a.lastPathComponent localizedCaseInsensitiveCompare:b.lastPathComponent];
        }];
    [self.tableView reloadData];
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section { return self.entries.count; }
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    NSURL *url = self.entries[indexPath.row];
    NSNumber *directory = nil, *size = nil;
    [url getResourceValue:&directory forKey:NSURLIsDirectoryKey error:nil];
    [url getResourceValue:&size forKey:NSURLFileSizeKey error:nil];
    UITableViewCell *cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:nil];
    cell.textLabel.text = url.lastPathComponent;
    cell.detailTextLabel.text = directory.boolValue ? @"Ordner" : WGFormatBytes(size);
    cell.imageView.image = [UIImage systemImageNamed:directory.boolValue ? @"folder.fill" : @"doc.fill"];
    cell.accessoryType = directory.boolValue ? UITableViewCellAccessoryDisclosureIndicator : UITableViewCellAccessoryNone;
    return cell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    NSURL *url = self.entries[indexPath.row];
    NSNumber *directory = nil;
    [url getResourceValue:&directory forKey:NSURLIsDirectoryKey error:nil];
    if (directory.boolValue) {
        [self.navigationController pushViewController:[[WGFileBrowserViewController alloc]
            initWithURL:url title:url.lastPathComponent] animated:YES];
    } else {
        UIActivityViewController *share = [[UIActivityViewController alloc] initWithActivityItems:@[url] applicationActivities:nil];
        share.popoverPresentationController.sourceView = self.view;
        [self presentViewController:share animated:YES completion:nil];
    }
}

@end
