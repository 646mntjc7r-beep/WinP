#import "WGRuntimeViewController.h"
#import "WGMetalView.h"
#import "WGCompositor.h"
#import "WGStore.h"
#include "wg_engine.h"
#include "wg_blink_bridge.h"
#include "wg_log.h"
#include "wg_win32_files.h"
#include "wg_win32_windows.h"
#import <Metal/Metal.h>
#import <QuartzCore/QuartzCore.h>
#import <UniformTypeIdentifiers/UniformTypeIdentifiers.h>
#include <math.h>
#include <unistd.h>

@interface WGRuntimeViewController () <UITextFieldDelegate, UIGestureRecognizerDelegate>
@property (nonatomic) NSDictionary *program;
@property (nonatomic) NSDictionary *bottle;
@property (nonatomic) WGMetalView *metalView;
@property (nonatomic) WGCompositor *compositor;
@property (nonatomic) id<MTLCommandQueue> commandQueue;
@property (nonatomic) CADisplayLink *displayLink;
@property (nonatomic) UILabel *statusLabel;
@property (nonatomic) UISegmentedControl *touchMode;
@property (nonatomic) UIScrollView *keyBar;
@property (nonatomic) UITextField *keyboardProxy;
@property (nonatomic) CAShapeLayer *cursorLayer;
@property (nonatomic) CGPoint cursor;
@property (nonatomic) CGPoint lastScroll;
@property (nonatomic) NSMutableSet<NSNumber *> *activeModifiers;
@property (nonatomic) NSURL *sharedFolderURL;
@property (nonatomic) NSThread *engineThread;
@property (atomic) BOOL engineThreadRunning;
@property (atomic) BOOL closing;
@property (nonatomic, assign) WGEngine *engine;
@property (nonatomic) NSInteger virtualWidth;
@property (nonatomic) NSInteger virtualHeight;
@end

@implementation WGRuntimeViewController

- (instancetype)initWithProgram:(NSDictionary *)program {
    self = [super initWithNibName:nil bundle:nil];
    if (self) {
        _program = [program copy];
        _bottle = [[WGStore shared] bottleWithID:program[@"bottleID"]];
        _activeModifiers = [NSMutableSet set];
        NSString *resolution = _bottle[@"resolution"] ?: @"Auto";
        NSDictionary *sizes = @{ @"800×600": @[@800, @600], @"1024×768": @[@1024, @768],
                                 @"1280×720": @[@1280, @720], @"1280×800": @[@1280, @800],
                                 @"1920×1080": @[@1920, @1080], @"Auto": @[@1280, @720] };
        NSArray *size = sizes[resolution] ?: sizes[@"Auto"];
        _virtualWidth = [size[0] integerValue];
        _virtualHeight = [size[1] integerValue];
        _cursor = CGPointMake(_virtualWidth / 2.0, _virtualHeight / 2.0);
        self.modalPresentationStyle = UIModalPresentationFullScreen;
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = UIColor.blackColor;
    [self buildMetalSurface];
    [self buildChrome];
    [self installGestures];
    [self startRuntime];
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    UIApplication.sharedApplication.idleTimerDisabled = YES;
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    UIApplication.sharedApplication.idleTimerDisabled = NO;
}

- (BOOL)prefersStatusBarHidden { return YES; }
- (BOOL)prefersHomeIndicatorAutoHidden { return YES; }
- (UIInterfaceOrientationMask)supportedInterfaceOrientations { return UIInterfaceOrientationMaskLandscape; }
- (BOOL)shouldAutorotate { return YES; }

- (void)buildMetalSurface {
    self.metalView = [[WGMetalView alloc] initWithFrame:self.view.bounds];
    self.metalView.translatesAutoresizingMaskIntoConstraints = NO;
    [self.view addSubview:self.metalView];
    [NSLayoutConstraint activateConstraints:@[
        [self.metalView.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor],
        [self.metalView.trailingAnchor constraintEqualToAnchor:self.view.trailingAnchor],
        [self.metalView.topAnchor constraintEqualToAnchor:self.view.topAnchor],
        [self.metalView.bottomAnchor constraintEqualToAnchor:self.view.bottomAnchor]
    ]];
    id<MTLDevice> device = self.metalView.metalLayer.device;
    self.commandQueue = [device newCommandQueue];
    self.compositor = [[WGCompositor alloc] initWithDevice:device];
    self.cursorLayer = [CAShapeLayer layer];
    self.cursorLayer.fillColor = UIColor.whiteColor.CGColor;
    self.cursorLayer.strokeColor = UIColor.blackColor.CGColor;
    self.cursorLayer.lineWidth = 1.5;
    self.cursorLayer.path = [UIBezierPath bezierPathWithOvalInRect:CGRectMake(-5, -5, 10, 10)].CGPath;
    [self.metalView.layer addSublayer:self.cursorLayer];
}

- (UIButton *)chromeButton:(NSString *)title action:(SEL)action {
    UIButton *button = [UIButton buttonWithType:UIButtonTypeSystem];
    button.translatesAutoresizingMaskIntoConstraints = NO;
    [button setTitle:title forState:UIControlStateNormal];
    [button setTitleColor:UIColor.whiteColor forState:UIControlStateNormal];
    button.titleLabel.font = [UIFont systemFontOfSize:14 weight:UIFontWeightSemibold];
    button.backgroundColor = [UIColor colorWithWhite:0.12 alpha:0.86];
    button.layer.cornerRadius = 9;
    button.contentEdgeInsets = UIEdgeInsetsMake(7, 11, 7, 11);
    [button addTarget:self action:action forControlEvents:UIControlEventTouchUpInside];
    return button;
}

- (void)buildChrome {
    UIButton *close = [self chromeButton:@"Fertig" action:@selector(closeRuntime)];
    UIButton *keyboard = [self chromeButton:@"Tastatur" action:@selector(showKeyboard)];
    UIButton *logs = [self chromeButton:@"Logs" action:@selector(showLogs)];
    self.touchMode = [[UISegmentedControl alloc] initWithItems:@[@"Direkt", @"Trackpad"]];
    self.touchMode.translatesAutoresizingMaskIntoConstraints = NO;
    self.touchMode.selectedSegmentIndex = 0;
    self.touchMode.selectedSegmentTintColor = [UIColor colorWithRed:0.18 green:0.47 blue:0.95 alpha:1];
    [self.touchMode setTitleTextAttributes:@{NSForegroundColorAttributeName: UIColor.whiteColor} forState:UIControlStateNormal];

    self.statusLabel = [UILabel new];
    self.statusLabel.translatesAutoresizingMaskIntoConstraints = NO;
    self.statusLabel.textColor = UIColor.whiteColor;
    self.statusLabel.font = [UIFont monospacedSystemFontOfSize:12 weight:UIFontWeightMedium];
    self.statusLabel.text = @"Runtime wird vorbereitet …";

    UIStackView *top = [[UIStackView alloc] initWithArrangedSubviews:@[close, self.statusLabel, self.touchMode, logs, keyboard]];
    top.translatesAutoresizingMaskIntoConstraints = NO;
    top.axis = UILayoutConstraintAxisHorizontal;
    top.spacing = 8;
    top.alignment = UIStackViewAlignmentCenter;
    top.layoutMargins = UIEdgeInsetsMake(6, 8, 6, 8);
    top.layoutMarginsRelativeArrangement = YES;
    top.backgroundColor = [UIColor colorWithWhite:0.03 alpha:0.88];
    [self.view addSubview:top];

    self.keyBar = [UIScrollView new];
    self.keyBar.translatesAutoresizingMaskIntoConstraints = NO;
    self.keyBar.backgroundColor = [UIColor colorWithWhite:0.04 alpha:0.92];
    self.keyBar.hidden = YES;
    [self.view addSubview:self.keyBar];
    [self populateKeyBar];

    self.keyboardProxy = [[UITextField alloc] initWithFrame:CGRectMake(0, 0, 1, 1)];
    self.keyboardProxy.delegate = self;
    self.keyboardProxy.autocorrectionType = UITextAutocorrectionTypeNo;
    self.keyboardProxy.autocapitalizationType = UITextAutocapitalizationTypeNone;
    self.keyboardProxy.spellCheckingType = UITextSpellCheckingTypeNo;
    self.keyboardProxy.textContentType = UITextContentTypeNone;
    self.keyboardProxy.alpha = 0.01;
    [self.view addSubview:self.keyboardProxy];

    [NSLayoutConstraint activateConstraints:@[
        [top.leadingAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.leadingAnchor],
        [top.trailingAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.trailingAnchor],
        [top.topAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.topAnchor],
        [top.heightAnchor constraintEqualToConstant:48],
        [self.statusLabel.widthAnchor constraintGreaterThanOrEqualToConstant:160],
        [self.keyBar.leadingAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.leadingAnchor],
        [self.keyBar.trailingAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.trailingAnchor],
        [self.keyBar.bottomAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.bottomAnchor],
        [self.keyBar.heightAnchor constraintEqualToConstant:48]
    ]];
}

- (void)populateKeyBar {
    NSArray<NSDictionary *> *keys = @[
        @{ @"t": @"ESC", @"v": @0x1B }, @{ @"t": @"TAB", @"v": @0x09 },
        @{ @"t": @"CTRL", @"v": @0x11, @"m": @YES }, @{ @"t": @"ALT", @"v": @0x12, @"m": @YES },
        @{ @"t": @"SHIFT", @"v": @0x10, @"m": @YES }, @{ @"t": @"WIN", @"v": @0x5B, @"m": @YES },
        @{ @"t": @"←", @"v": @0x25 }, @{ @"t": @"↑", @"v": @0x26 },
        @{ @"t": @"↓", @"v": @0x28 }, @{ @"t": @"→", @"v": @0x27 },
        @{ @"t": @"DEL", @"v": @0x2E }, @{ @"t": @"ENTER", @"v": @0x0D }
    ];
    NSMutableArray *all = [keys mutableCopy];
    for (int i = 0; i < 12; i++) [all addObject:@{ @"t": [NSString stringWithFormat:@"F%d", i + 1], @"v": @(0x70 + i) }];
    UIStackView *stack = [UIStackView new];
    stack.translatesAutoresizingMaskIntoConstraints = NO;
    stack.axis = UILayoutConstraintAxisHorizontal;
    stack.spacing = 6;
    stack.layoutMargins = UIEdgeInsetsMake(5, 8, 5, 8);
    stack.layoutMarginsRelativeArrangement = YES;
    [self.keyBar addSubview:stack];
    for (NSDictionary *key in all) {
        UIButton *button = [UIButton buttonWithType:UIButtonTypeSystem];
        [button setTitle:key[@"t"] forState:UIControlStateNormal];
        [button setTitleColor:UIColor.whiteColor forState:UIControlStateNormal];
        button.titleLabel.font = [UIFont monospacedSystemFontOfSize:12 weight:UIFontWeightSemibold];
        button.backgroundColor = [UIColor colorWithWhite:0.18 alpha:1];
        button.layer.cornerRadius = 7;
        button.tag = [key[@"v"] integerValue];
        button.accessibilityValue = [key[@"m"] boolValue] ? @"modifier" : @"key";
        [button.widthAnchor constraintGreaterThanOrEqualToConstant:46].active = YES;
        [button addTarget:self action:@selector(toolbarKey:) forControlEvents:UIControlEventTouchUpInside];
        [stack addArrangedSubview:button];
    }
    [NSLayoutConstraint activateConstraints:@[
        [stack.leadingAnchor constraintEqualToAnchor:self.keyBar.contentLayoutGuide.leadingAnchor],
        [stack.trailingAnchor constraintEqualToAnchor:self.keyBar.contentLayoutGuide.trailingAnchor],
        [stack.topAnchor constraintEqualToAnchor:self.keyBar.contentLayoutGuide.topAnchor],
        [stack.bottomAnchor constraintEqualToAnchor:self.keyBar.contentLayoutGuide.bottomAnchor],
        [stack.heightAnchor constraintEqualToAnchor:self.keyBar.frameLayoutGuide.heightAnchor]
    ]];
}

- (void)installGestures {
    UITapGestureRecognizer *single = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(singleTap:)];
    UITapGestureRecognizer *doubleTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(doubleTap:)];
    doubleTap.numberOfTapsRequired = 2;
    [single requireGestureRecognizerToFail:doubleTap];
    UILongPressGestureRecognizer *longPress = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(longPress:)];
    longPress.minimumPressDuration = 0.48;
    UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(oneFingerPan:)];
    pan.maximumNumberOfTouches = 1;
    UIPanGestureRecognizer *scroll = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(twoFingerPan:)];
    scroll.minimumNumberOfTouches = 2;
    scroll.maximumNumberOfTouches = 2;
    for (UIGestureRecognizer *gesture in @[single, doubleTap, longPress, pan, scroll]) {
        gesture.delegate = self;
        [self.metalView addGestureRecognizer:gesture];
    }
}

- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gesture shouldReceiveTouch:(UITouch *)touch {
    return touch.view == self.metalView;
}

- (CGPoint)virtualPointForLocation:(CGPoint)point {
    CGSize bounds = self.metalView.bounds.size;
    if (bounds.width <= 0 || bounds.height <= 0) return CGPointZero;
    CGFloat scale = MIN(bounds.width / self.virtualWidth, bounds.height / self.virtualHeight);
    CGFloat ox = (bounds.width - self.virtualWidth * scale) / 2.0;
    CGFloat oy = (bounds.height - self.virtualHeight * scale) / 2.0;
    CGFloat x = (point.x - ox) / scale;
    CGFloat y = (point.y - oy) / scale;
    return CGPointMake(MAX(0, MIN(self.virtualWidth - 1, x)), MAX(0, MIN(self.virtualHeight - 1, y)));
}

- (CGPoint)screenPointForVirtual:(CGPoint)point {
    CGSize bounds = self.metalView.bounds.size;
    CGFloat scale = MIN(bounds.width / self.virtualWidth, bounds.height / self.virtualHeight);
    return CGPointMake((bounds.width - self.virtualWidth * scale) / 2.0 + point.x * scale,
                       (bounds.height - self.virtualHeight * scale) / 2.0 + point.y * scale);
}

- (CGPoint)inputPoint:(UIGestureRecognizer *)gesture {
    if (self.touchMode.selectedSegmentIndex == 0) {
        self.cursor = [self virtualPointForLocation:[gesture locationInView:self.metalView]];
    }
    [self updateCursor];
    return self.cursor;
}

- (void)updateCursor {
    self.cursorLayer.hidden = (self.touchMode.selectedSegmentIndex == 0);
    self.cursorLayer.position = [self screenPointForVirtual:self.cursor];
}

- (void)postClickAt:(CGPoint)p right:(BOOL)right count:(NSInteger)count {
    if (!self.engine) return;
    if (wg_engine_dialog_active(self.engine) && !right) {
        uint32_t control = wg_engine_hit_test(self.engine, (int)p.x, (int)p.y);
        if (control) { wg_engine_dialog_command(self.engine, control); return; }
    }
    uint32_t down = right ? 0x0204 : 0x0201;
    uint32_t up = right ? 0x0205 : 0x0202;
    for (NSInteger i = 0; i < count; i++) {
        wg_engine_post_mouse(self.engine, down, (int)p.x, (int)p.y, 0);
        wg_engine_post_mouse(self.engine, up, (int)p.x, (int)p.y, 0);
    }
}

- (void)singleTap:(UITapGestureRecognizer *)gesture { [self postClickAt:[self inputPoint:gesture] right:NO count:1]; }
- (void)doubleTap:(UITapGestureRecognizer *)gesture { [self postClickAt:[self inputPoint:gesture] right:NO count:2]; }

- (void)longPress:(UILongPressGestureRecognizer *)gesture {
    if (gesture.state == UIGestureRecognizerStateBegan)
        [self postClickAt:[self inputPoint:gesture] right:YES count:1];
}

- (void)oneFingerPan:(UIPanGestureRecognizer *)gesture {
    if (!self.engine) return;
    CGPoint p;
    if (self.touchMode.selectedSegmentIndex == 0) {
        p = [self inputPoint:gesture];
        if (gesture.state == UIGestureRecognizerStateBegan)
            wg_engine_post_mouse(self.engine, 0x0201, (int)p.x, (int)p.y, 0);
        wg_engine_post_mouse(self.engine, 0x0200, (int)p.x, (int)p.y, 0);
        if (gesture.state == UIGestureRecognizerStateEnded || gesture.state == UIGestureRecognizerStateCancelled)
            wg_engine_post_mouse(self.engine, 0x0202, (int)p.x, (int)p.y, 0);
    } else {
        CGPoint delta = [gesture translationInView:self.metalView];
        [gesture setTranslation:CGPointZero inView:self.metalView];
        self.cursor = CGPointMake(MAX(0, MIN(self.virtualWidth - 1, self.cursor.x + delta.x * 1.4)),
                                  MAX(0, MIN(self.virtualHeight - 1, self.cursor.y + delta.y * 1.4)));
        [self updateCursor];
        wg_engine_post_mouse(self.engine, 0x0200, (int)self.cursor.x, (int)self.cursor.y, 0);
    }
}

- (void)twoFingerPan:(UIPanGestureRecognizer *)gesture {
    if (!self.engine) return;
    CGPoint delta = [gesture translationInView:self.metalView];
    if (fabs(delta.y) >= 8) {
        CGPoint p = [self inputPoint:gesture];
        int wheel = delta.y < 0 ? 120 : -120;
        wg_engine_post_mouse(self.engine, 0x020A, (int)p.x, (int)p.y, wheel);
        [gesture setTranslation:CGPointZero inView:self.metalView];
    }
}

- (void)toolbarKey:(UIButton *)sender {
    NSNumber *key = @(sender.tag);
    if ([sender.accessibilityValue isEqualToString:@"modifier"]) {
        BOOL active = [self.activeModifiers containsObject:key];
        if (active) [self.activeModifiers removeObject:key]; else [self.activeModifiers addObject:key];
        sender.backgroundColor = active ? [UIColor colorWithWhite:0.18 alpha:1]
                                        : [UIColor colorWithRed:0.18 green:0.47 blue:0.95 alpha:1];
        wg_engine_post_key(self.engine, sender.tag, !active);
        return;
    }
    wg_engine_post_key(self.engine, sender.tag, true);
    wg_engine_post_key(self.engine, sender.tag, false);
}

- (void)showKeyboard {
    self.keyBar.hidden = !self.keyBar.hidden;
    if (![self.keyboardProxy isFirstResponder]) [self.keyboardProxy becomeFirstResponder];
    else [self.keyboardProxy resignFirstResponder];
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    if (string.length == 0) {
        wg_engine_post_key(self.engine, 0x08, true);
        wg_engine_post_key(self.engine, 0x08, false);
        return NO;
    }
    for (NSUInteger i = 0; i < string.length; i++)
        wg_engine_post_text(self.engine, [string characterAtIndex:i]);
    return NO;
}

- (NSArray<UIKeyCommand *> *)keyCommands {
    NSMutableArray *commands = [NSMutableArray array];
    NSDictionary *map = @{ UIKeyInputEscape: @0x1B, UIKeyInputUpArrow: @0x26,
                           UIKeyInputDownArrow: @0x28, UIKeyInputLeftArrow: @0x25,
                           UIKeyInputRightArrow: @0x27 };
    for (NSString *input in map) {
        UIKeyCommand *command = [UIKeyCommand keyCommandWithInput:input modifierFlags:0 action:@selector(hardwareKey:)];
        [commands addObject:command];
    }
    return commands;
}

- (void)hardwareKey:(UIKeyCommand *)command {
    NSDictionary *map = @{ UIKeyInputEscape: @0x1B, UIKeyInputUpArrow: @0x26,
                           UIKeyInputDownArrow: @0x28, UIKeyInputLeftArrow: @0x25,
                           UIKeyInputRightArrow: @0x27 };
    uint32_t key = [map[command.input] unsignedIntValue];
    wg_engine_post_key(self.engine, key, true);
    wg_engine_post_key(self.engine, key, false);
}

- (void)startRuntime {
    if (![self.program[@"extension"] isEqualToString:@"exe"]) {
        self.statusLabel.text = self.program[@"compatibilityReason"];
        return;
    }
    NSString *programPath = [WGStore.shared URLForProgram:self.program].path;
    NSString *bottlePath = [WGStore.shared URLForBottle:self.bottle].path;
    NSError *sharedError = nil;
    self.sharedFolderURL = [WGStore.shared beginAccessingSharedFolderForBottle:self.bottle error:&sharedError];
    wg_files_set_bottle_root(bottlePath.fileSystemRepresentation);
    wg_files_set_shared_drive(self.sharedFolderURL.path.fileSystemRepresentation);
    wg_wm_set_desktop_size((int32_t)self.virtualWidth, (int32_t)self.virtualHeight);
    self.statusLabel.text = [NSString stringWithFormat:@"%@ · %@ · JIT %@",
                             self.program[@"architecture"], self.bottle[@"name"],
                             wg_blink_has_jit() ? @"JA" : @"NEIN"];

    __weak typeof(self) weakSelf = self;
    dispatch_async(dispatch_get_global_queue(QOS_CLASS_USER_INITIATED, 0), ^{
        WGRuntimeViewController *strongSelf = weakSelf;
        if (!strongSelf || strongSelf.closing) return;
        strongSelf.engine = wg_engine_create();
        wg_engine_set_jit_enabled(strongSelf.engine, [strongSelf.bottle[@"jit"] boolValue]);
        BOOL initialized = strongSelf.engine && wg_engine_init(strongSelf.engine);
        BOOL loaded = initialized && wg_engine_load_pe(strongSelf.engine, programPath.fileSystemRepresentation);
        BOOL running = loaded && wg_engine_run(strongSelf.engine);
        dispatch_async(dispatch_get_main_queue(), ^{
            if (!strongSelf || strongSelf.closing) return;
            if (running) {
                [WGStore.shared markProgramLaunched:strongSelf.program];
                [strongSelf startEngineThread];
                [strongSelf startDisplayLink];
            } else {
                [strongSelf presentRuntimeError:@"Die PE-Datei konnte nicht geladen oder gestartet werden. Öffne die Logs für die genaue Loader-/DLL-Meldung."];
            }
        });
    });
}

- (void)startEngineThread {
    self.engineThreadRunning = YES;
    self.engineThread = [[NSThread alloc] initWithTarget:self selector:@selector(engineLoop) object:nil];
    self.engineThread.name = @"PocketWin-Engine";
    self.engineThread.stackSize = 4 * 1024 * 1024;
    self.engineThread.qualityOfService = NSQualityOfServiceUserInteractive;
    [self.engineThread start];
}

- (void)engineLoop {
    while (self.engineThreadRunning && !self.closing) {
        WGEngineState state = wg_engine_get_state(self.engine);
        if (state == WG_ENGINE_RUNNING) {
            wg_engine_tick(self.engine);
        } else if (state == WG_ENGINE_PAUSED) {
            wg_engine_tick(self.engine);
            usleep(8000);
        } else {
            break;
        }
    }
    if (!self.closing) {
        const char *next = wg_engine_take_pending_exec(self.engine);
        if (next && next[0]) {
            NSString *path = [NSString stringWithUTF8String:next];
            WG_LOGI("App", "Child process requested: %s", next);
            // The current HLE runtime supports one guest process at a time.
            dispatch_async(dispatch_get_main_queue(), ^{
                self.statusLabel.text = [NSString stringWithFormat:@"Kindprozess: %@", path.lastPathComponent];
            });
        } else {
            dispatch_async(dispatch_get_main_queue(), ^{ self.statusLabel.text = @"Programm beendet"; });
        }
    }
}

- (void)startDisplayLink {
    self.displayLink = [CADisplayLink displayLinkWithTarget:self selector:@selector(renderFrame:)];
    self.displayLink.preferredFrameRateRange = CAFrameRateRangeMake(30, 120, 60);
    [self.displayLink addToRunLoop:NSRunLoop.mainRunLoop forMode:NSRunLoopCommonModes];
}

- (void)renderFrame:(CADisplayLink *)link {
    [self updateCursor];
    id<CAMetalDrawable> drawable = [self.metalView.metalLayer nextDrawable];
    if (!drawable || !self.commandQueue) return;
    if (wg_wm_visible_count() > 0) {
        [self.compositor renderWindowsToDrawable:drawable commandQueue:self.commandQueue
                                      screenSize:self.metalView.metalLayer.drawableSize];
    } else {
        MTLRenderPassDescriptor *pass = [MTLRenderPassDescriptor new];
        pass.colorAttachments[0].texture = drawable.texture;
        pass.colorAttachments[0].loadAction = MTLLoadActionClear;
        pass.colorAttachments[0].storeAction = MTLStoreActionStore;
        pass.colorAttachments[0].clearColor = MTLClearColorMake(0.025, 0.035, 0.06, 1);
        id<MTLCommandBuffer> commands = [self.commandQueue commandBuffer];
        id<MTLRenderCommandEncoder> encoder = [commands renderCommandEncoderWithDescriptor:pass];
        [encoder endEncoding];
        [commands presentDrawable:drawable];
        [commands commit];
    }
}

- (void)presentRuntimeError:(NSString *)message {
    self.statusLabel.text = @"Start fehlgeschlagen";
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Windows-Programm konnte nicht starten"
                                                                   message:message
                                                            preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:@"Logs" style:UIAlertActionStyleDefault handler:^(UIAlertAction *a) { [self showLogs]; }]];
    [alert addAction:[UIAlertAction actionWithTitle:@"Schließen" style:UIAlertActionStyleCancel handler:nil]];
    [self presentViewController:alert animated:YES completion:nil];
}

- (void)showLogs {
    NSString *log = WGLogCenter.shared.completeLog;
    UIViewController *controller = [UIViewController new];
    controller.title = @"Debug-Konsole";
    controller.view.backgroundColor = UIColor.systemBackgroundColor;
    UITextView *text = [[UITextView alloc] initWithFrame:controller.view.bounds];
    text.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    text.editable = NO;
    text.font = [UIFont monospacedSystemFontOfSize:11 weight:UIFontWeightRegular];
    text.text = log.length ? log : @"Noch keine Logs.";
    [controller.view addSubview:text];
    UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:controller];
    controller.navigationItem.rightBarButtonItems = @[
        [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemAction target:self action:@selector(exportLogs)],
        [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemDone target:self action:@selector(dismissLogView)]
    ];
    [self presentViewController:nav animated:YES completion:nil];
}

- (void)dismissLogView { [self.presentedViewController dismissViewControllerAnimated:YES completion:nil]; }

- (void)exportLogs {
    NSError *error = nil;
    NSURL *url = [WGLogCenter.shared writeExportFile:&error];
    if (!url) { [self presentRuntimeError:error.localizedDescription]; return; }
    UIActivityViewController *share = [[UIActivityViewController alloc] initWithActivityItems:@[url] applicationActivities:nil];
    [self.presentedViewController presentViewController:share animated:YES completion:nil];
}

- (void)closeRuntime {
    if (self.closing) return;
    self.closing = YES;
    self.engineThreadRunning = NO;
    [self.displayLink invalidate];
    self.displayLink = nil;
    if (self.engine) wg_engine_stop(self.engine);
    NSThread *thread = self.engineThread;
    dispatch_async(dispatch_get_global_queue(QOS_CLASS_USER_INITIATED, 0), ^{
        for (int i = 0; i < 1000 && thread && !thread.finished; i++) usleep(1000);
        WGEngine *engine = self.engine;
        self.engine = NULL;
        if (!thread || thread.finished) {
            if (engine) wg_engine_destroy(engine);
        } else {
            // Never free a VM that is still executing. This rare timeout leaks
            // one process-local engine until app exit, which is safer than a
            // use-after-free in untrusted guest code.
            WG_LOGE("App", "Engine thread did not stop within one second; VM retained for safety");
        }
        wg_files_set_shared_drive(NULL);
        [WGStore.shared endAccessingSharedFolderURL:self.sharedFolderURL];
        dispatch_async(dispatch_get_main_queue(), ^{ [self dismissViewControllerAnimated:YES completion:nil]; });
    });
}

@end
