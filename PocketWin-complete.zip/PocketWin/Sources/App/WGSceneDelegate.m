#import "WGSceneDelegate.h"
#import "WGRootViewController.h"
#import "WGStore.h"
#include "wg_log.h"

@implementation WGSceneDelegate

- (void)scene:(UIScene *)scene
    willConnectToSession:(UISceneSession *)session
                 options:(UISceneConnectionOptions *)connectionOptions {
    UIWindowScene *windowScene = (UIWindowScene *)scene;
    if (!windowScene) return;

    wg_log_init();
    [WGLogCenter.shared start];
    (void)WGStore.shared;

    self.window = [[UIWindow alloc] initWithWindowScene:windowScene];
    self.window.rootViewController = [WGRootViewController new];
    self.window.tintColor = [UIColor colorWithRed:0.16 green:0.43 blue:0.94 alpha:1];
    [self.window makeKeyAndVisible];
    WG_LOGI("App", "PocketWin launcher ready");
}

- (void)scene:(UIScene *)scene openURLContexts:(NSSet<UIOpenURLContext *> *)URLContexts {
    for (UIOpenURLContext *context in URLContexts) {
        NSError *error = nil;
        if (![WGStore.shared importProgramAtURL:context.URL bottleID:nil error:&error])
            WG_LOGE("App", "Open-in import failed: %s", error.localizedDescription.UTF8String);
    }
}

@end

