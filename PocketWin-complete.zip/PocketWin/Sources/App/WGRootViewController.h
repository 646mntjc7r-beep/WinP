#import <UIKit/UIKit.h>

@interface WGRootViewController : UITabBarController
@end

