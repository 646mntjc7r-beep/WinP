#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface WGRuntimeViewController : UIViewController
- (instancetype)initWithProgram:(NSDictionary *)program;
@end

NS_ASSUME_NONNULL_END

