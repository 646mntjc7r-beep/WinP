#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

extern NSNotificationName const WGStoreDidChangeNotification;
extern NSNotificationName const WGLogDidChangeNotification;

@interface WGStore : NSObject

@property (class, nonatomic, readonly) WGStore *shared;
@property (nonatomic, readonly) NSArray<NSDictionary *> *programs;
@property (nonatomic, readonly) NSArray<NSDictionary *> *bottles;
@property (nonatomic, readonly) NSURL *rootURL;

- (NSDictionary *)createBottleNamed:(NSString *)name;
- (nullable NSDictionary *)duplicateBottle:(NSDictionary *)bottle error:(NSError **)error;
- (BOOL)deleteBottle:(NSDictionary *)bottle error:(NSError **)error;
- (nullable NSDictionary *)importProgramAtURL:(NSURL *)source
                                     bottleID:(nullable NSString *)bottleID
                                        error:(NSError **)error;
- (BOOL)deleteProgram:(NSDictionary *)program error:(NSError **)error;
- (void)markProgramLaunched:(NSDictionary *)program;
- (BOOL)updateProgram:(NSDictionary *)program values:(NSDictionary *)values error:(NSError **)error;
- (nullable NSDictionary *)programWithID:(NSString *)identifier;
- (nullable NSDictionary *)bottleWithID:(NSString *)identifier;
- (NSURL *)URLForProgram:(NSDictionary *)program;
- (NSURL *)URLForBottle:(NSDictionary *)bottle;
- (BOOL)updateBottle:(NSDictionary *)bottle values:(NSDictionary *)values error:(NSError **)error;
- (BOOL)setSharedFolderURL:(NSURL *)url forBottle:(NSDictionary *)bottle error:(NSError **)error;
- (nullable NSURL *)beginAccessingSharedFolderForBottle:(NSDictionary *)bottle
                                                   error:(NSError **)error;
- (void)endAccessingSharedFolderURL:(nullable NSURL *)url;
- (nullable NSDictionary *)importBottleDirectoryAtURL:(NSURL *)url error:(NSError **)error;

@end

@interface WGLogCenter : NSObject

@property (class, nonatomic, readonly) WGLogCenter *shared;
- (void)start;
- (NSArray<NSString *> *)lines;
- (NSString *)completeLog;
- (NSURL *)writeExportFile:(NSError **)error;
- (void)clear;

@end

NS_ASSUME_NONNULL_END
