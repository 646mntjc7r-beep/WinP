#import "WGStore.h"
#include "wg_pe_loader.h"
#include "wg_log.h"

NSNotificationName const WGStoreDidChangeNotification = @"WGStoreDidChangeNotification";
NSNotificationName const WGLogDidChangeNotification = @"WGLogDidChangeNotification";

static NSString *const WGErrorDomain = @"com.pocketwin.error";

static NSString *WGISODate(NSDate *date) {
    static NSISO8601DateFormatter *formatter;
    static dispatch_once_t once;
    dispatch_once(&once, ^{ formatter = [NSISO8601DateFormatter new]; });
    return [formatter stringFromDate:date];
}

static NSError *WGError(NSInteger code, NSString *message) {
    return [NSError errorWithDomain:WGErrorDomain code:code
                           userInfo:@{NSLocalizedDescriptionKey: message}];
}

@interface WGStore ()
@property (nonatomic) NSMutableArray<NSMutableDictionary *> *mutablePrograms;
@property (nonatomic) NSMutableArray<NSMutableDictionary *> *mutableBottles;
@property (nonatomic, readwrite) NSURL *rootURL;
@end

@implementation WGStore

+ (WGStore *)shared {
    static WGStore *store;
    static dispatch_once_t once;
    dispatch_once(&once, ^{ store = [[WGStore alloc] initPrivate]; });
    return store;
}

- (instancetype)init { return WGStore.shared; }

- (instancetype)initPrivate {
    self = [super init];
    if (!self) return nil;
    NSURL *support = [[[NSFileManager defaultManager]
        URLsForDirectory:NSApplicationSupportDirectory inDomains:NSUserDomainMask] firstObject];
    _rootURL = [support URLByAppendingPathComponent:@"PocketWin" isDirectory:YES];
    _mutablePrograms = [NSMutableArray array];
    _mutableBottles = [NSMutableArray array];
    [self prepareRoot];
    [self loadMetadata];
    if (_mutableBottles.count == 0) [self createBottleNamed:@"Standard"];
    return self;
}

- (NSArray<NSDictionary *> *)programs { return [self.mutablePrograms copy]; }
- (NSArray<NSDictionary *> *)bottles { return [self.mutableBottles copy]; }

- (NSURL *)metadataURL { return [self.rootURL URLByAppendingPathComponent:@"metadata.json"]; }
- (NSURL *)bottlesURL { return [self.rootURL URLByAppendingPathComponent:@"Bottles" isDirectory:YES]; }

- (void)prepareRoot {
    NSFileManager *fm = NSFileManager.defaultManager;
    [fm createDirectoryAtURL:self.rootURL withIntermediateDirectories:YES attributes:nil error:nil];
    [fm createDirectoryAtURL:self.bottlesURL withIntermediateDirectories:YES attributes:nil error:nil];
    [self.rootURL setResourceValue:@YES forKey:NSURLIsExcludedFromBackupKey error:nil];
}

- (void)loadMetadata {
    NSData *data = [NSData dataWithContentsOfURL:self.metadataURL];
    if (!data) return;
    NSDictionary *json = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:nil];
    if (![json isKindOfClass:NSDictionary.class]) return;
    NSArray *programs = json[@"programs"];
    NSArray *bottles = json[@"bottles"];
    if ([programs isKindOfClass:NSArray.class]) {
        [self.mutablePrograms removeAllObjects];
        for (NSDictionary *item in programs)
            if ([item isKindOfClass:NSDictionary.class]) [self.mutablePrograms addObject:[item mutableCopy]];
    }
    if ([bottles isKindOfClass:NSArray.class]) {
        [self.mutableBottles removeAllObjects];
        for (NSDictionary *item in bottles)
            if ([item isKindOfClass:NSDictionary.class]) [self.mutableBottles addObject:[item mutableCopy]];
    }
}

- (void)save {
    NSDictionary *json = @{ @"schema": @1,
                            @"programs": self.mutablePrograms,
                            @"bottles": self.mutableBottles };
    NSError *error = nil;
    NSData *data = [NSJSONSerialization dataWithJSONObject:json options:NSJSONWritingPrettyPrinted error:&error];
    if (data && [data writeToURL:self.metadataURL options:NSDataWritingAtomic error:&error]) {
        dispatch_async(dispatch_get_main_queue(), ^{
            [NSNotificationCenter.defaultCenter postNotificationName:WGStoreDidChangeNotification object:self];
        });
    } else {
        WG_LOGE("Store", "Metadata save failed: %s", error.localizedDescription.UTF8String);
    }
}

- (NSURL *)URLForBottle:(NSDictionary *)bottle {
    return [self.bottlesURL URLByAppendingPathComponent:bottle[@"id"] isDirectory:YES];
}

- (NSURL *)URLForProgram:(NSDictionary *)program {
    NSString *relative = program[@"relativePath"] ?: @"";
    return [self.rootURL URLByAppendingPathComponent:relative];
}

- (NSDictionary *)createBottleNamed:(NSString *)name {
    NSString *identifier = NSUUID.UUID.UUIDString.lowercaseString;
    NSMutableDictionary *bottle = [@{
        @"id": identifier,
        @"name": name.length ? name : @"Neue Bottle",
        @"windowsVersion": @"Windows 10",
        @"ramMB": @1024,
        @"cpuCores": @2,
        @"resolution": @"Auto",
        @"dpi": @96,
        @"renderer": @"Metal/GDI",
        @"jit": @NO,
        @"environment": @{},
        @"dllOverrides": @{},
        @"createdAt": WGISODate(NSDate.date)
    } mutableCopy];
    NSURL *root = [self URLForBottle:bottle];
    NSArray<NSString *> *directories = @[
        @"drive_c/Program Files", @"drive_c/Program Files (x86)",
        @"drive_c/users/pocketwin/Desktop", @"drive_c/users/pocketwin/Documents",
        @"drive_c/users/pocketwin/AppData/Local", @"drive_c/users/pocketwin/AppData/Roaming",
        @"drive_c/windows/system32", @"drive_c/Temp"
    ];
    NSFileManager *fm = NSFileManager.defaultManager;
    for (NSString *path in directories) {
        [fm createDirectoryAtURL:[root URLByAppendingPathComponent:path isDirectory:YES]
     withIntermediateDirectories:YES attributes:nil error:nil];
    }
    NSString *systemReg = @"WINE REGISTRY Version 2\n\n[HKEY_LOCAL_MACHINE\\Software\\Microsoft\\Windows NT\\CurrentVersion]\n\"ProductName\"=\"Windows 10\"\n\"CurrentBuild\"=\"19045\"\n";
    NSString *userReg = @"WINE REGISTRY Version 2\n\n[HKEY_CURRENT_USER\\Software\\PocketWin]\n\"BottleVersion\"=\"1\"\n";
    [systemReg writeToURL:[root URLByAppendingPathComponent:@"system.reg"] atomically:YES encoding:NSUTF8StringEncoding error:nil];
    [userReg writeToURL:[root URLByAppendingPathComponent:@"user.reg"] atomically:YES encoding:NSUTF8StringEncoding error:nil];
    [@"WINE REGISTRY Version 2\n" writeToURL:[root URLByAppendingPathComponent:@"userdef.reg"] atomically:YES encoding:NSUTF8StringEncoding error:nil];
    [self.mutableBottles addObject:bottle];
    [self save];
    return bottle;
}

- (NSDictionary *)duplicateBottle:(NSDictionary *)bottle error:(NSError **)error {
    if (!bottle) { if (error) *error = WGError(10, @"Bottle wurde nicht gefunden."); return nil; }
    NSString *newID = NSUUID.UUID.UUIDString.lowercaseString;
    NSURL *source = [self URLForBottle:bottle];
    NSURL *destination = [self.bottlesURL URLByAppendingPathComponent:newID isDirectory:YES];
    if (![NSFileManager.defaultManager copyItemAtURL:source toURL:destination error:error]) return nil;
    NSMutableDictionary *copy = [bottle mutableCopy];
    copy[@"id"] = newID;
    copy[@"name"] = [NSString stringWithFormat:@"%@ Kopie", bottle[@"name"] ?: @"Bottle"];
    copy[@"createdAt"] = WGISODate(NSDate.date);
    [copy removeObjectForKey:@"sharedFolderBookmark"];
    [self.mutableBottles addObject:copy];
    [self save];
    return copy;
}

- (BOOL)deleteBottle:(NSDictionary *)bottle error:(NSError **)error {
    if (self.mutableBottles.count <= 1) {
        if (error) *error = WGError(11, @"Mindestens eine Bottle muss vorhanden bleiben.");
        return NO;
    }
    NSString *identifier = bottle[@"id"];
    if (!identifier) return NO;
    if (![NSFileManager.defaultManager removeItemAtURL:[self URLForBottle:bottle] error:error]) return NO;
    NSIndexSet *programIndexes = [self.mutablePrograms indexesOfObjectsPassingTest:^BOOL(NSDictionary *item, NSUInteger idx, BOOL *stop) {
        return [item[@"bottleID"] isEqualToString:identifier];
    }];
    [self.mutablePrograms removeObjectsAtIndexes:programIndexes];
    NSMutableDictionary *mutableBottle = (NSMutableDictionary *)bottle;
    [self.mutableBottles removeObjectIdenticalTo:mutableBottle];
    if ([self.mutableBottles containsObject:mutableBottle]) [self.mutableBottles removeObject:mutableBottle];
    [self save];
    return YES;
}

- (NSDictionary *)bottleWithID:(NSString *)identifier {
    for (NSDictionary *bottle in self.mutableBottles)
        if ([bottle[@"id"] isEqualToString:identifier]) return bottle;
    return nil;
}

- (NSDictionary *)programWithID:(NSString *)identifier {
    for (NSDictionary *program in self.mutablePrograms)
        if ([program[@"id"] isEqualToString:identifier]) return program;
    return nil;
}

- (NSDictionary *)analysisForFile:(NSURL *)url extension:(NSString *)extension {
    if (![@"exe" isEqualToString:extension]) {
        NSString *reason = [extension isEqualToString:@"msi"]
            ? @"MSI ist importierbar, aber Windows Installer ist in dieser Runtime nicht implementiert."
            : @"Batch-Dateien benötigen cmd.exe; ein freier kompatibler cmd-Host ist nicht enthalten.";
        return @{ @"architecture": @"Nicht analysiert", @"machine": @0,
                  @"subsystem": @"Skript/Installer", @"entryPoint": @0,
                  @"imports": @[], @"missingDLLs": @[],
                  @"compatibility": @"Niedrig", @"compatibilityReason": reason };
    }

    WGPEImage *image = wg_pe_load_file(url.fileSystemRepresentation);
    if (!image) return @{ @"parseError": @YES };
    NSMutableArray *imports = [NSMutableArray array];
    NSMutableArray *missing = [NSMutableArray array];
    NSSet *supported = [NSSet setWithArray:@[
        @"kernel32.dll", @"kernelbase.dll", @"ntdll.dll", @"user32.dll",
        @"gdi32.dll", @"gdi32full.dll", @"advapi32.dll", @"shell32.dll",
        @"shlwapi.dll", @"comctl32.dll", @"ole32.dll", @"oleaut32.dll",
        @"ws2_32.dll", @"winhttp.dll", @"wininet.dll", @"secur32.dll",
        @"schannel.dll", @"crypt32.dll", @"bcrypt.dll", @"version.dll",
        @"msvcrt.dll", @"ucrtbase.dll", @"vcruntime140.dll", @"msvcp140.dll",
        @"wsock32.dll", @"sspicli.dll", @"rpcrt4.dll", @"iphlpapi.dll"
    ]];
    for (int i = 0; i < image->num_imports; i++) {
        NSString *dll = [NSString stringWithUTF8String:image->imports[i].dll_name] ?: @"?";
        [imports addObject:dll];
        NSString *lower = dll.lowercaseString;
        BOOL apiSet = [lower hasPrefix:@"api-ms-win-"] || [lower hasPrefix:@"ext-ms-win-"];
        if (![supported containsObject:lower] && !apiSet) [missing addObject:dll];
    }
    NSString *architecture;
    switch (image->machine) {
        case 0x014c: architecture = @"x86"; break;
        case 0x8664: architecture = @"x64"; break;
        case 0xaa64: architecture = @"ARM64"; break;
        case 0x01c4: architecture = @"ARM"; break;
        default: architecture = [NSString stringWithUTF8String:wg_pe_machine_name(image->machine)] ?: @"Unbekannt";
    }
    NSString *compatibility = @"Hoch";
    NSString *reason = @"PE32 mit ausschließlich bekannten Win32-Importbibliotheken.";
    if (missing.count) {
        compatibility = @"Niedrig";
        reason = [NSString stringWithFormat:@"Nicht abgedeckte Importbibliotheken: %@", [missing componentsJoinedByString:@", "]];
    } else if (image->is_64bit) {
        compatibility = @"Mittel";
        reason = @"x64-Code kann ausgeführt werden; GUI-Eingabe ist derzeit auf PE32 vollständig verdrahtet.";
    } else if ([architecture hasPrefix:@"ARM"]) {
        compatibility = @"Niedrig";
        reason = @"Die CPU-Schicht implementiert x86/x64, nicht Windows-on-ARM-Binärdateien.";
    }
    NSDictionary *result = @{
        @"architecture": architecture,
        @"machine": @(image->machine),
        @"subsystem": [NSString stringWithUTF8String:wg_pe_subsystem_name(image->subsystem)] ?: @"Unbekannt",
        @"entryPoint": @(image->entry_point),
        @"imageBase": @(image->image_base),
        @"imageSize": @(image->size_of_image),
        @"sectionCount": @(image->num_sections),
        @"imports": imports,
        @"missingDLLs": missing,
        @"compatibility": compatibility,
        @"compatibilityReason": reason
    };
    wg_pe_image_free(image);
    return result;
}

- (NSDictionary *)importProgramAtURL:(NSURL *)source bottleID:(NSString *)bottleID error:(NSError **)error {
    NSString *extension = source.pathExtension.lowercaseString;
    NSSet *allowed = [NSSet setWithArray:@[@"exe", @"msi", @"bat", @"cmd"]];
    if (![allowed containsObject:extension]) {
        if (error) *error = WGError(20, @"Unterstützt werden .exe, .msi, .bat und .cmd.");
        return nil;
    }
    NSDictionary *bottle = bottleID ? [self bottleWithID:bottleID] : self.mutableBottles.firstObject;
    if (!bottle) { if (error) *error = WGError(21, @"Es ist keine Bottle verfügbar."); return nil; }

    BOOL scoped = [source startAccessingSecurityScopedResource];
    NSNumber *size = nil;
    [source getResourceValue:&size forKey:NSURLFileSizeKey error:nil];
    NSString *identifier = NSUUID.UUID.UUIDString.lowercaseString;
    NSString *safeName = source.lastPathComponent.length ? source.lastPathComponent : [@"programm." stringByAppendingString:extension];
    NSURL *programDir = [[self URLForBottle:bottle] URLByAppendingPathComponent:[@"drive_c/Program Files/PocketWin/" stringByAppendingString:identifier] isDirectory:YES];
    [NSFileManager.defaultManager createDirectoryAtURL:programDir withIntermediateDirectories:YES attributes:nil error:error];
    NSURL *destination = [programDir URLByAppendingPathComponent:safeName];
    BOOL copied = [NSFileManager.defaultManager copyItemAtURL:source toURL:destination error:error];
    if (scoped) [source stopAccessingSecurityScopedResource];
    if (!copied) return nil;

    NSDictionary *analysis = [self analysisForFile:destination extension:extension];
    if ([analysis[@"parseError"] boolValue]) {
        [NSFileManager.defaultManager removeItemAtURL:programDir error:nil];
        if (error) *error = WGError(22, @"Die Datei besitzt keinen gültigen oder unterstützten PE-Header.");
        return nil;
    }
    NSString *relative = [destination.path substringFromIndex:self.rootURL.path.length + 1];
    NSMutableDictionary *program = [@{
        @"id": identifier,
        @"name": source.URLByDeletingPathExtension.lastPathComponent ?: safeName,
        @"fileName": safeName,
        @"relativePath": relative,
        @"bottleID": bottle[@"id"],
        @"size": size ?: @0,
        @"importedAt": WGISODate(NSDate.date),
        @"lastLaunch": @"",
        @"extension": extension
    } mutableCopy];
    [program addEntriesFromDictionary:analysis];
    [self.mutablePrograms addObject:program];
    [self save];
    WG_LOGI("Store", "Imported %s (%s)", safeName.UTF8String, [program[@"architecture"] UTF8String]);
    return program;
}

- (BOOL)deleteProgram:(NSDictionary *)program error:(NSError **)error {
    NSURL *url = [self URLForProgram:program];
    NSURL *directory = [url URLByDeletingLastPathComponent];
    if (![NSFileManager.defaultManager removeItemAtURL:directory error:error]) return NO;
    [self.mutablePrograms removeObject:(id)program];
    [self save];
    return YES;
}

- (void)markProgramLaunched:(NSDictionary *)program {
    NSMutableDictionary *stored = (NSMutableDictionary *)[self programWithID:program[@"id"]];
    stored[@"lastLaunch"] = WGISODate(NSDate.date);
    [self save];
}

- (BOOL)updateProgram:(NSDictionary *)program values:(NSDictionary *)values error:(NSError **)error {
    NSMutableDictionary *stored = (NSMutableDictionary *)[self programWithID:program[@"id"]];
    if (!stored) { if (error) *error = WGError(23, @"Programm wurde nicht gefunden."); return NO; }
    NSSet *allowed = [NSSet setWithArray:@[@"name", @"bottleID"]];
    for (NSString *key in values) if ([allowed containsObject:key]) stored[key] = values[key];
    [self save];
    return YES;
}

- (BOOL)updateBottle:(NSDictionary *)bottle values:(NSDictionary *)values error:(NSError **)error {
    NSMutableDictionary *stored = (NSMutableDictionary *)[self bottleWithID:bottle[@"id"]];
    if (!stored) { if (error) *error = WGError(30, @"Bottle wurde nicht gefunden."); return NO; }
    NSSet *allowed = [NSSet setWithArray:@[@"name", @"windowsVersion", @"ramMB", @"cpuCores",
                                             @"resolution", @"dpi", @"renderer", @"jit",
                                             @"environment", @"dllOverrides"]];
    for (NSString *key in values) if ([allowed containsObject:key]) stored[key] = values[key];
    [self save];
    return YES;
}

- (BOOL)setSharedFolderURL:(NSURL *)url forBottle:(NSDictionary *)bottle error:(NSError **)error {
    // iOS document-picker URLs are already security-scoped. The explicit
    // security-scope bookmark option is macOS/Catalyst-only.
    NSData *bookmark = [url bookmarkDataWithOptions:(NSURLBookmarkCreationOptions)0
                     includingResourceValuesForKeys:nil relativeToURL:nil error:error];
    if (!bookmark) return NO;
    NSMutableDictionary *stored = (NSMutableDictionary *)[self bottleWithID:bottle[@"id"]];
    stored[@"sharedFolderBookmark"] = [bookmark base64EncodedStringWithOptions:0];
    stored[@"sharedFolderName"] = url.lastPathComponent ?: @"Freigabe";
    [self save];
    return YES;
}

- (NSURL *)beginAccessingSharedFolderForBottle:(NSDictionary *)bottle error:(NSError **)error {
    NSString *encoded = bottle[@"sharedFolderBookmark"];
    if (!encoded.length) return nil;
    NSData *data = [[NSData alloc] initWithBase64EncodedString:encoded options:0];
    BOOL stale = NO;
    NSURL *url = [NSURL URLByResolvingBookmarkData:data options:(NSURLBookmarkResolutionOptions)0
                                      relativeToURL:nil bookmarkDataIsStale:&stale error:error];
    if (!url || ![url startAccessingSecurityScopedResource]) {
        if (url && error && !*error) *error = WGError(31, @"Der freigegebene Ordner ist nicht mehr erreichbar.");
        return nil;
    }
    if (stale) [self setSharedFolderURL:url forBottle:bottle error:nil];
    return url;
}

- (void)endAccessingSharedFolderURL:(NSURL *)url {
    [url stopAccessingSecurityScopedResource];
}

- (NSDictionary *)importBottleDirectoryAtURL:(NSURL *)url error:(NSError **)error {
    BOOL scoped = [url startAccessingSecurityScopedResource];
    NSString *identifier = NSUUID.UUID.UUIDString.lowercaseString;
    NSURL *destination = [self.bottlesURL URLByAppendingPathComponent:identifier isDirectory:YES];
    BOOL copied = [NSFileManager.defaultManager copyItemAtURL:url toURL:destination error:error];
    if (scoped) [url stopAccessingSecurityScopedResource];
    if (!copied) return nil;
    NSURL *driveC = [destination URLByAppendingPathComponent:@"drive_c" isDirectory:YES];
    NSNumber *isDirectory = nil;
    if (![driveC getResourceValue:&isDirectory forKey:NSURLIsDirectoryKey error:nil] || !isDirectory.boolValue) {
        [NSFileManager.defaultManager removeItemAtURL:destination error:nil];
        if (error) *error = WGError(32, @"Der ausgewählte Ordner enthält kein drive_c-Verzeichnis.");
        return nil;
    }
    NSMutableDictionary *bottle = [[self createBottleNamed:url.lastPathComponent ?: @"Importierte Bottle"] mutableCopy];
    NSURL *created = [self URLForBottle:bottle];
    [NSFileManager.defaultManager removeItemAtURL:created error:nil];
    bottle[@"id"] = identifier;
    [self.mutableBottles removeLastObject];
    [self.mutableBottles addObject:bottle];
    [self save];
    return bottle;
}

@end

@interface WGLogCenter ()
@property (nonatomic) NSMutableArray<NSString *> *mutableLines;
@property (nonatomic) dispatch_queue_t queue;
@end

static void WGLogCallbackFunction(WGLogLevel level, const char *tag, const char *message, void *userdata) {
    WGLogCenter *center = (__bridge WGLogCenter *)userdata;
    NSString *line = [NSString stringWithUTF8String:message ?: ""] ?: @"";
    dispatch_async(center.queue, ^{
        NSString *prefix = @[@"DBG", @"INF", @"WRN", @"ERR", @"FTL"][MAX(0, MIN(4, (int)level))];
        [center.mutableLines addObject:[NSString stringWithFormat:@"[%@] %@", prefix, line]];
        if (center.mutableLines.count > 2000)
            [center.mutableLines removeObjectsInRange:NSMakeRange(0, center.mutableLines.count - 2000)];
        dispatch_async(dispatch_get_main_queue(), ^{
            [NSNotificationCenter.defaultCenter postNotificationName:WGLogDidChangeNotification object:center];
        });
    });
}

@implementation WGLogCenter

+ (WGLogCenter *)shared {
    static WGLogCenter *center;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        center = [WGLogCenter new];
        center.mutableLines = [NSMutableArray array];
        center.queue = dispatch_queue_create("com.pocketwin.logs", DISPATCH_QUEUE_SERIAL);
    });
    return center;
}

- (void)start { wg_log_set_callback(WGLogCallbackFunction, (__bridge void *)self); }

- (NSArray<NSString *> *)lines {
    __block NSArray *copy;
    dispatch_sync(self.queue, ^{ copy = [self.mutableLines copy]; });
    return copy;
}

- (NSString *)completeLog { return [[self lines] componentsJoinedByString:@"\n"]; }

- (NSURL *)writeExportFile:(NSError **)error {
    NSURL *url = [NSURL fileURLWithPath:[NSTemporaryDirectory() stringByAppendingPathComponent:@"PocketWin.log"]];
    if (![[self completeLog] writeToURL:url atomically:YES encoding:NSUTF8StringEncoding error:error]) return nil;
    return url;
}

- (void)clear {
    dispatch_sync(self.queue, ^{ [self.mutableLines removeAllObjects]; });
    [NSNotificationCenter.defaultCenter postNotificationName:WGLogDidChangeNotification object:self];
}

@end
