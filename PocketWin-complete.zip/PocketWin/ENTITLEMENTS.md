# Entitlement matrix

| Entitlement or capability | Required | Development certificate | Notes |
|---|---:|---|---|
| get-task-allow | No app setting | Added by a development provisioning profile | Used by Xcode debugging; do not hard-code it for distribution |
| Files/document picker | No entitlement | Yes | Public UIDocumentPicker and security-scoped bookmarks |
| increased-memory-limit | No | Only if the profile authorizes it | Optional Apple-managed capability |
| extended-virtual-addressing | No | Only if the profile authorizes it | Optional Apple-managed capability |
| dynamic-codesigning / executable memory | Not used by default | Not generally granted by an ordinary profile | JIT deployments need an external, lawful enablement mechanism |
| private platform-application-style entitlements | Never | No | Explicitly unsupported |

The default PocketWin.entitlements file is empty. This keeps the core launcher,
No-JIT interpreter, bottles, Metal renderer, files and networking compatible
with ordinary development signing.

