# PocketWin

PocketWin is a native iOS launcher and experimental local compatibility runtime
for Windows PE executables. It does not use a remote computer, a Windows image
or a virtual machine. Imported code runs locally through this pipeline:

    Windows PE32 / PE32+
            ↓
    PE loader and import resolver
            ↓
    Blink x86 / x64 interpreter (optional JIT build)
            ↓
    Win32 high-level API thunks
            ↓
    UIKit, Metal, POSIX files and sockets

This is real guest-instruction execution, not an importer that displays a
placeholder message. It is also not complete Wine: compatibility is limited to
the Win32 calls implemented by the HLE layer.

## Included application features

- Native Apps, Bottles, Files and Settings tabs
- Import of EXE, MSI, BAT and CMD files through the iOS document picker
- Persistent program library with PE architecture, subsystem, size, imports,
  missing-DLL heuristic, compatibility rating, bottle and last launch
- Independent bottle directories with drive_c, three persistent registry files,
  Windows-version metadata, resolution, DPI, renderer, environment and DLL
  override configuration
- Persistent security-scoped directory bookmark mapped as D:
- Bottle creation, duplication, deletion, folder import and Files-share export
- Direct-touch and trackpad modes, click, double-click, right-click, drag and
  two-finger wheel input for 32-bit Win32 windows
- Software keyboard proxy, Bluetooth keyboard key commands and a Windows
  special-key toolbar
- Metal compositor for Win32/GDI framebuffers and dialog controls
- TCP/UDP/DNS and HTTP/HTTPS compatibility paths through native sockets,
  WinHTTP and the Security framework where the requested API is implemented
- Live debug console with export
- Bundled real PE32 GUI fixtures in Resources/TestPrograms

## Current compatibility boundary

| Area | Current state |
|---|---|
| PE32 x86 console and basic GUI | Executed locally; best-supported target |
| PE32+ x64 code | Loader and CPU execution present; Win32 coverage is smaller |
| ARM/ARM64 Windows PE | Detected, not executed |
| GDI / GDI+ style drawing | GDI subset rendered through Metal |
| DirectX 9–12, DXVK, VKD3D | Not included |
| OpenGL | Not included |
| MSI | Imported and diagnosed; no MSI engine |
| BAT / CMD | Imported and diagnosed; no cmd.exe |
| Audio | No waveOut/DirectSound bridge yet |
| Network | Native socket, WinHTTP and SChannel subsets |
| Child processes | One guest process at a time |
| Wine/Mono/Gecko/.NET/VC++ | Not bundled |

The app never silently claims support for the unavailable rows. Their UI status
and launch errors state the missing runtime layer.

## Build on macOS

Requirements:

- macOS with Xcode 15 or newer
- An iPhone running iOS 17 or newer
- A development team only when installing on a device

Steps:

1. Open PocketWin.xcodeproj.
2. Select the PocketWin target and your development Team.
3. Change com.pocketwin.app if that bundle identifier is unavailable to your
   team.
4. Select the physical iPhone and press Run.

The first build compiles the fully vendored Blink sources into Derived Data. It
does not fetch dependencies and does not require XcodeGen or GNU Make.

The source bundle can be checked without Xcode first:

    Scripts/validate_project.py

For an unsigned IPA on a Mac:

    chmod +x Scripts/build_blink_ios.sh Scripts/build_unsigned_ipa.sh
    Scripts/build_unsigned_ipa.sh

The result is Build/PocketWin-unsigned.ipa. Signing is intentionally left to
the user.

## JIT modes

The checked-in project uses POCKETWIN_ENABLE_JIT=NO. That produces the portable
interpreter build and requires no JIT entitlement. A JIT-capable binary can be
built by overriding the setting:

    xcodebuild -project PocketWin.xcodeproj -scheme PocketWin \
      -sdk iphoneos POCKETWIN_ENABLE_JIT=YES build

Compilation alone does not make executable-memory permission available on a
stock device. If the operating environment does not grant it, use the default
No-JIT build. Each bottle can disable JIT in a JIT-capable binary; the runtime
reports the actual compiled capability.

## Entitlements

Sources/App/PocketWin.entitlements is the default and intentionally empty.
Document-picker access and files in the app container use public APIs and need
no special entitlement. Development signing supplies get-task-allow through
the provisioning profile when debugging.

Sources/App/PocketWin.OptionalMemory.entitlements documents two Apple-managed
optional capabilities:

- com.apple.developer.kernel.increased-memory-limit
- com.apple.developer.kernel.extended-virtual-addressing

They are not required by PocketWin and are not selected by default. A profile
must authorize them before that optional file can be used. No private Apple
entitlement is assumed.

## Tests

The parser, memory, CPU and execution fixtures are under Tests. On Linux with
GCC, Make and the zlib development package, run both real PE32 acceptance
tests:

    Tests/build_linux.sh

The first fixture exits with `0x1FFFF` only after all 17 guest x86 instruction
checks pass. The second executes a Win32/GDI program and succeeds only after
the runtime creates and shows its `PocketWin GDI Test` window.

On Apple Silicon macOS, the equivalent headless runtime builder is:

    Tests/build_mac.sh

On iPhone, the Settings tab can install and launch the bundled WGTest.exe.
Normal users import their own files with the document picker.

## Source and licenses

The runtime began from WineGlass and pins Blink source in-tree. Exact revisions
and licenses are recorded in PROVENANCE.md and Resources/THIRD_PARTY_NOTICES.txt.
No Microsoft binaries, fonts or Windows components are redistributed.
