#!/bin/bash
set -euo pipefail

# Builds the same No-JIT runtime as a command-line executable on Apple Silicon
# macOS. All source inputs are vendored; no external Blink checkout is used.

project_root="$(cd "$(dirname "$0")/.." && pwd)"
build_root="${BUILD_DIR:-/tmp/PocketWinHostBuild}"
object_root="$build_root/blink-objects"
config_root="$build_root/config"
mkdir -p "$object_root" "$config_root"

sdk="$(xcrun --sdk macosx --show-sdk-path)"
compiler="$(xcrun --sdk macosx --find clang)"
archiver="$(xcrun --sdk macosx --find ar)"
blink_root="$project_root/Vendor/blink/upstream"

{
  echo '#define DISABLE_JIT 1'
  cat "$project_root/Vendor/blink/include/config.h"
} > "$config_root/config.h"

flags=(
  -arch arm64 -isysroot "$sdk" -mmacosx-version-min=13.0 -std=gnu11
  -fno-common -fPIC -O1 -g -U_FORTIFY_SOURCE -D_FILE_OFFSET_BITS=64
  -D_DARWIN_C_SOURCE -D_DEFAULT_SOURCE -D_BSD_SOURCE -D_GNU_SOURCE
  -iquote "$config_root" -iquote "$blink_root" -Wno-everything
)

objects=()
while IFS= read -r source; do
  object="$object_root/$(basename "$source" .c).o"
  objects+=("$object")
  "$compiler" "${flags[@]}" -c "$source" -o "$object"
done < <(find "$blink_root/blink" -maxdepth 1 -type f -name '*.c' \
          ! -name 'blink.c' ! -name 'blinkenlights.c' | LC_ALL=C sort)
"$archiver" rcs "$build_root/blink.a" "${objects[@]}"
"$compiler" "${flags[@]}" -c "$project_root/Vendor/blink/wg_blink_impl.c" -o "$build_root/wg_blink_impl.o"

engine_sources=(
  Sources/Core/wg_engine.c Sources/Core/wg_blink_bridge.c Sources/Core/wg_blink_stubs.c
  Sources/Core/wg_log.c Sources/CPU/wg_x86_decode.c Sources/CPU/wg_x86_interp.c
  Sources/CPU/wg_x86_state.c Sources/PE/wg_pe_loader.c Sources/Memory/wg_memory.c
  Sources/Win32/wg_dll_mapper.c Sources/Win32/wg_nsis_extract.c
  Sources/Win32/wg_schannel.c Sources/Win32/wg_threading.c
  Sources/Win32/wg_win32_bitmap.c Sources/Win32/wg_win32_files.c
  Sources/Win32/wg_win32_gdi.c Sources/Win32/wg_win32_windows.c
  Sources/Win32/wg_winhttp.c Sources/Win32/wg_winsock.c Sources/LZMA/LzmaDec.c
)
absolute_sources=()
for source in "${engine_sources[@]}"; do absolute_sources+=("$project_root/$source"); done

"$compiler" -arch arm64 -isysroot "$sdk" -mmacosx-version-min=13.0 -std=gnu11 -O1 -g \
  -DTARGET_OS_IOS=0 -D_DARWIN_C_SOURCE -iquote "$config_root" \
  -I"$project_root/Sources/Core" -I"$project_root/Sources/CPU" -I"$project_root/Sources/PE" \
  -I"$project_root/Sources/Memory" -I"$project_root/Sources/Win32" \
  -I"$project_root/Sources/Graphics" -I"$project_root/Sources/LZMA" \
  "${absolute_sources[@]}" "$project_root/Tests/run_exe.c" \
  "$build_root/wg_blink_impl.o" "$build_root/blink.a" \
  -framework Security -framework CoreFoundation -framework CoreGraphics -framework CoreText \
  -lz -o "$build_root/pocketwin_run"

echo "$build_root/pocketwin_run"
