// run_exe.c — Headless host harness: load a Windows .exe through the PocketWin
// engine and tick it to completion, printing all logs to stdout. Lets us run &
// diagnose (e.g. Steam) on the Mac directly, with no device round-trip.
//
// Usage: run_exe <path-to.exe> [max_seconds] [expected_exit_code|-]
//                [expected_window_title]

#include "wg_log.h"
#include "wg_engine.h"
#include "wg_win32_files.h"
#include "wg_win32_windows.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

static bool visible_window_has_title(const char *expected) {
    WGWindowManager *wm = wg_wm_get();
    for (int i = 0; i < wm->count; i++) {
        WGWin32Window *window = &wm->windows[i];
        if (!window->alive || !window->visible) continue;
        size_t j = 0;
        while (expected[j] && j < 255 && window->title[j] == (uint8_t)expected[j]) j++;
        if (!expected[j] && window->title[j] == 0) return true;
    }
    return false;
}

int main(int argc, char *argv[]) {
    if (argc < 2) {
        fprintf(stderr, "usage: %s <file.exe> [max_seconds] [expected_exit_code|-] [expected_window_title]\n", argv[0]);
        return 2;
    }
    const char *exe = argv[1];
    double max_seconds = (argc >= 3) ? atof(argv[2]) : 30.0;
    bool check_exit = argc >= 4 && strcmp(argv[3], "-") != 0;
    uint32_t expected_exit = check_exit ? (uint32_t)strtoul(argv[3], NULL, 0) : 0;
    const char *expected_title = argc >= 5 ? argv[4] : NULL;

    wg_log_init();
    WG_LOGI("RUN", "=== PocketWin headless runner ===");
    WG_LOGI("RUN", "exe=%s max_seconds=%.1f", exe, max_seconds);

    const char *test_bottle = getenv("POCKETWIN_TEST_BOTTLE");
    if (test_bottle && test_bottle[0]) wg_files_set_bottle_root(test_bottle);

    WGEngine *engine = wg_engine_create();
    if (!engine || !wg_engine_init(engine)) { WG_LOGE("RUN", "engine init failed"); return 1; }
    if (!wg_engine_load_pe(engine, exe))     { WG_LOGE("RUN", "PE load failed");    return 1; }
    if (!wg_engine_run(engine))              { WG_LOGE("RUN", "engine start failed"); return 1; }

    struct timespec t0; clock_gettime(CLOCK_MONOTONIC, &t0);
    unsigned long long ticks = 0;
    bool found_window = false;
    for (;;) {
        wg_engine_tick(engine);
        ticks++;
        if (expected_title && visible_window_has_title(expected_title)) {
            found_window = true;
            WG_LOGI("RUN", "visible Win32 window reached: %s", expected_title);
            break;
        }
        WGEngineState st = wg_engine_get_state(engine);
        if (st != WG_ENGINE_RUNNING && st != WG_ENGINE_PAUSED) {
            WG_LOGI("RUN", "engine stopped: state=%d after %llu ticks", st, ticks);
            break;
        }
        if ((ticks & 0x3FF) == 0) {
            struct timespec t1; clock_gettime(CLOCK_MONOTONIC, &t1);
            double el = (t1.tv_sec - t0.tv_sec) + (t1.tv_nsec - t0.tv_nsec) / 1e9;
            if (el > max_seconds) { WG_LOGW("RUN", "time limit %.1fs hit (%llu ticks)", max_seconds, ticks); break; }
        }
    }
    uint32_t exit_code = 0;
    bool has_exit_code = wg_engine_get_exit_code(engine, &exit_code);
    if (has_exit_code) WG_LOGI("RUN", "guest exit code: 0x%X", exit_code);
    if (check_exit && (!has_exit_code || exit_code != expected_exit)) {
        WG_LOGE("RUN", "expected exit code 0x%X, got %s0x%X",
                expected_exit, has_exit_code ? "" : "no code / ", exit_code);
        wg_engine_destroy(engine);
        return 3;
    }
    if (expected_title && !found_window) {
        WG_LOGE("RUN", "expected visible Win32 window not reached: %s", expected_title);
        wg_engine_destroy(engine);
        return 4;
    }
    WG_LOGI("RUN", "done");
    wg_engine_destroy(engine);
    return 0;
}
