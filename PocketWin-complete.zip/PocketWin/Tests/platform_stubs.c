// Headless implementations for the Apple-only drawing and TLS adapters.
// They let the complete PE/CPU/Win32 core run its console fixtures on Linux;
// the iOS target links the real CoreText/Security implementations instead.

#include "wg_win32_gdi.h"
#include "wg_schannel.h"
#include "wg_winhttp.h"
#include <stdlib.h>

struct WGSchannel { int unused; };
struct WGWinHttp { int unused; };

WGSchannel *wg_schannel_create(void) { return calloc(1, sizeof(WGSchannel)); }
void wg_schannel_destroy(WGSchannel *sc) { free(sc); }
bool wg_schannel_handle(WGSchannel *sc, const char *fn, uint32_t *args,
                        uint64_t *out_ret, void *blink) {
    (void)sc; (void)fn; (void)args; (void)blink;
    if (out_ret) *out_ret = 0;
    return false;
}
ssize_t wg_schannel_send(WGSchannel *sc, int fd, const void *buf, size_t len) {
    (void)sc; (void)fd; (void)buf; (void)len; return -1;
}
ssize_t wg_schannel_recv(WGSchannel *sc, int fd, void *buf, size_t len) {
    (void)sc; (void)fd; (void)buf; (void)len; return -1;
}
bool wg_schannel_has_tls(WGSchannel *sc, int fd) { (void)sc; (void)fd; return false; }

WGWinHttp *wg_winhttp_create(void) { return calloc(1, sizeof(WGWinHttp)); }
void wg_winhttp_destroy(WGWinHttp *wh) { free(wh); }
bool wg_winhttp_handle(WGWinHttp *wh, const char *fn, uint32_t *args,
                       uint64_t *out_ret, void *blink) {
    (void)wh; (void)fn; (void)args; (void)blink;
    if (out_ret) *out_ret = 0;
    return false;
}

uint32_t wg_gdi_get_dc(uint32_t hwnd) { return hwnd ? WG_DC_BASE : 0; }
void wg_gdi_release_dc(uint32_t hdc) { (void)hdc; }
void wg_gdi_set_text_color(uint32_t hdc, uint32_t colorref) { (void)hdc; (void)colorref; }
void wg_gdi_set_bk_mode(uint32_t hdc, int mode) { (void)hdc; (void)mode; }
void wg_gdi_set_bk_color(uint32_t hdc, uint32_t colorref) { (void)hdc; (void)colorref; }
void wg_gdi_fill_rect(uint32_t hdc, int l, int t, int r, int b, uint32_t colorref) {
    (void)hdc; (void)l; (void)t; (void)r; (void)b; (void)colorref;
}
void wg_gdi_text_out(uint32_t hdc, int x, int y, const uint16_t *utf16, int count) {
    (void)hdc; (void)x; (void)y; (void)utf16; (void)count;
}
void wg_gdi_text_out_caption(uint32_t hdc, int x, int y, const uint16_t *utf16, int count) {
    (void)hdc; (void)x; (void)y; (void)utf16; (void)count;
}
void wg_gdi_text_box(uint32_t hdc, int x, int y, int w, int h,
                     const uint16_t *utf16, int count) {
    (void)hdc; (void)x; (void)y; (void)w; (void)h; (void)utf16; (void)count;
}
int wg_gdi_text_width(uint32_t hdc, const uint16_t *utf16, int count) {
    (void)hdc; (void)utf16; return count > 0 ? count * 8 : 0;
}
int wg_gdi_line_height(uint32_t hdc) { (void)hdc; return 16; }
void wg_gdi_select_font(uint32_t hdc, int px, bool bold, const char *name) {
    (void)hdc; (void)px; (void)bold; (void)name;
}
void wg_gdi_move_to(uint32_t hdc, int x, int y) { (void)hdc; (void)x; (void)y; }
void wg_gdi_line_to(uint32_t hdc, int x, int y) { (void)hdc; (void)x; (void)y; }
uint32_t wg_gdi_create_solid_brush(uint32_t colorref) { return colorref | 0x01000000u; }
uint32_t wg_gdi_brush_color(uint32_t hbrush, bool *found) {
    if (found) *found = hbrush != 0;
    return hbrush & 0x00ffffffu;
}
uint32_t wg_gdi_create_memory_dc(void) { return WG_DC_BASE + 1; }
void wg_gdi_delete_dc(uint32_t hdc) { (void)hdc; }
uint32_t wg_gdi_select_bitmap(uint32_t hdc, uint32_t hbitmap) { (void)hdc; return hbitmap; }
uint32_t wg_gdi_selected_bitmap(uint32_t hdc) { (void)hdc; return 0; }
void wg_gdi_blit(uint32_t hdc_dst, int dx, int dy, int dw, int dh,
                 uint32_t hdc_src, int sx, int sy, int sw, int sh) {
    (void)hdc_dst; (void)dx; (void)dy; (void)dw; (void)dh;
    (void)hdc_src; (void)sx; (void)sy; (void)sw; (void)sh;
}
void wg_gdi_draw_bitmap(uint32_t hdc_dst, int dx, int dy, int dw, int dh,
                        uint32_t hbitmap, int sx, int sy, int sw, int sh) {
    (void)hdc_dst; (void)dx; (void)dy; (void)dw; (void)dh;
    (void)hbitmap; (void)sx; (void)sy; (void)sw; (void)sh;
}
