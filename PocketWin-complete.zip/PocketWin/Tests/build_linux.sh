#!/bin/bash
set -euo pipefail

# Host-side verification for the self-contained PE runtime. This is not an iOS
# build; it compiles the same Blink interpreter and runs a real PE32 fixture.

project_root="$(cd "$(dirname "$0")/.." && pwd)"
build_root="${BUILD_DIR:-/tmp/PocketWinLinuxBuild}"
blink_root="$build_root/blink"

mkdir -p "$build_root"
if [[ ! -f "$blink_root/configure" ]]; then
  mkdir -p "$blink_root"
  cp -a "$project_root/Vendor/blink/upstream/." "$blink_root/"
fi

(
  cd "$blink_root"
  if [[ ! -f config.mk || ! -f config.h ]]; then
    ./configure --disable-jit --disable-threads --disable-sockets --disable-strace --disable-vfs
  fi
  make -j"${JOBS:-2}" o//blink/blink.a
)

common=(
  -std=gnu11 -O1 -g -fno-common -fPIC -U_FORTIFY_SOURCE
  -D_FILE_OFFSET_BITS=64 -D_DARWIN_C_SOURCE -D_DEFAULT_SOURCE -D_BSD_SOURCE -D_GNU_SOURCE
  -DPOCKETWIN_BLINK_JIT=0 -iquote "$blink_root"
)
gcc "${common[@]}" -c "$project_root/Vendor/blink/wg_blink_impl.c" \
  -o "$build_root/wg_blink_impl.o"

includes=(
  -I"$project_root/Sources/Core" -I"$project_root/Sources/CPU"
  -I"$project_root/Sources/PE" -I"$project_root/Sources/Memory"
  -I"$project_root/Sources/Win32" -I"$project_root/Sources/LZMA"
)
sources=(
  Sources/Core/wg_engine.c Sources/Core/wg_blink_bridge.c Sources/Core/wg_blink_stubs.c
  Sources/Core/wg_log.c Sources/CPU/wg_x86_decode.c Sources/CPU/wg_x86_interp.c
  Sources/CPU/wg_x86_state.c Sources/PE/wg_pe_loader.c Sources/Memory/wg_memory.c
  Sources/Win32/wg_dll_mapper.c Sources/Win32/wg_nsis_extract.c
  Sources/Win32/wg_threading.c Sources/Win32/wg_win32_bitmap.c
  Sources/Win32/wg_win32_files.c Sources/Win32/wg_win32_windows.c
  Sources/Win32/wg_winsock.c Sources/LZMA/LzmaDec.c
)
absolute_sources=()
for source in "${sources[@]}"; do absolute_sources+=("$project_root/$source"); done

gcc "${common[@]}" "${includes[@]}" "${absolute_sources[@]}" \
  "$project_root/Tests/platform_stubs.c" "$project_root/Tests/run_exe.c" \
  "$build_root/wg_blink_impl.o" "$blink_root/o//blink/blink.a" \
  -pthread -lm -lz -o "$build_root/pocketwin_run"

POCKETWIN_TEST_BOTTLE="$build_root/test-bottle" \
  "$build_root/pocketwin_run" "$project_root/Tests/WGProbe.exe" 10 0x1ffff
POCKETWIN_TEST_BOTTLE="$build_root/test-bottle" \
  "$build_root/pocketwin_run" "$project_root/Tests/WGTest.exe" 10 - "PocketWin GDI Test"
echo "Host runtime test passed"
