# Runtime architecture

PocketWin deliberately uses high-level emulation instead of a Windows VM.

1. WGStore imports the file into a persistent bottle and parses its PE headers.
2. wg_pe_loader maps sections and imports.
3. Blink executes x86 or x64 guest instructions on ARM64. The default build is
   interpreter-only.
4. wg_dll_mapper replaces supported imported Win32 functions with guest HLT
   thunks.
5. wg_engine handles each thunk with native iOS/POSIX services.
6. GDI writes per-window RGBA buffers. WGCompositor scales and draws them with
   Metal inside the runtime view.
7. UIKit gestures and keyboard events are queued at instruction-batch
   boundaries and dispatched to PE32 guest window procedures.

Wine, Box64 and FEX are not stacked together here. Wine itself needs a POSIX
host port and x86-on-ARM still needs a CPU layer; Box64 and FEX target Linux
userspace and Linux host libraries. A full QEMU/UTM path would provide broader
compatibility but also require an operating-system image and would violate the
minimal-runtime goal.

Global mutable compatibility state means only one guest process may run at a
time. Bottles remain independent on disk.

