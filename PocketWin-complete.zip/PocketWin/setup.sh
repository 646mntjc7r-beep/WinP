#!/bin/bash
set -euo pipefail

project_root="$(cd "$(dirname "$0")" && pwd)"

if ! command -v xcodebuild >/dev/null 2>&1; then
  echo "Xcode command-line tools were not found. Run this script on macOS with Xcode installed."
  exit 1
fi

chmod +x "$project_root/Scripts/build_blink_ios.sh" "$project_root/Scripts/build_unsigned_ipa.sh"
xcodebuild -project "$project_root/PocketWin.xcodeproj" -scheme PocketWin -list
echo "PocketWin is ready. Open $project_root/PocketWin.xcodeproj and select your development team."

