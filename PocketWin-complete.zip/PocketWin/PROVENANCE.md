# Source provenance

The project is intentionally self-contained and can be built without fetching
source code during the Xcode build.

| Component | Source | Pinned revision | License |
|---|---|---|---|
| WineGlass runtime base | https://github.com/Contonion/WineGlass | bf37a4d958c390c2fd6c59bbcc116a122a9bbdcd | Apache-2.0 (declared by upstream) |
| Blink CPU core | https://github.com/jart/blink | f006a4fc6f9b8de9272504fdff0dbbe5ce5dc580 | ISC |
| LZMA decoder | LZMA SDK | vendored with the base | Public domain |

The Blink Git metadata is not needed to build. Its exact source tree is stored
under Vendor/blink/upstream; the Xcode build phase compiles it into Derived Data
for the active iPhoneOS architecture.

